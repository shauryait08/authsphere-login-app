import { Request, Response } from 'express';
import bcrypt from 'bcryptjs';
import User, { IUser } from '../models/User';
import { isDatabaseConnected } from '../config/db';

// In-memory fallback storage in case MongoDB is offline during initial preview/local dev
interface InMemoryUser {
  id: string;
  name: string;
  mobile: string;
  email: string;
  password: string; // bcrypt hashed
  createdAt: Date;
}

const inMemoryUsers: InMemoryUser[] = [];

// Helper validation functions
export const isValidEmail = (email: string): boolean => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
};

export const isValidMobile = (mobile: string): boolean => {
  const cleaned = mobile.replace(/[\s\-\(\)\+]/g, '');
  return /^\d{10,15}$/.test(cleaned);
};

/**
 * Register a new user
 * POST /api/auth/register
 */
export const registerUser = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { name, mobile, email, password } = req.body;

    // Field existence check
    if (!name || !mobile || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'All fields (Name, Mobile, Email, Password) are required.',
      });
    }

    const trimmedName = String(name).trim();
    const trimmedMobile = String(mobile).trim();
    const trimmedEmail = String(email).trim().toLowerCase();
    const cleanPassword = String(password);

    // Validation checks
    if (trimmedName.length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Name must be at least 2 characters long.',
      });
    }

    if (!isValidMobile(trimmedMobile)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid 10-to-15 digit mobile number.',
      });
    }

    if (!isValidEmail(trimmedEmail)) {
      return res.status(400).json({
        success: false,
        message: 'Please enter a valid email address (e.g. user@example.com).',
      });
    }

    if (cleanPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.',
      });
    }

    // Check if user already exists
    if (isDatabaseConnected()) {
      const existingUser = await User.findOne({ email: trimmedEmail });
      if (existingUser) {
        return res.status(409).json({
          success: false,
          message: 'An account with this email address already exists. Please login.',
        });
      }

      // Create new Mongoose user (Pre-save hook will hash password with bcrypt)
      const newUser = new User({
        name: trimmedName,
        mobile: trimmedMobile,
        email: trimmedEmail,
        password: cleanPassword,
        createdAt: new Date(),
      });

      await newUser.save();

      return res.status(201).json({
        success: true,
        message: 'User registered successfully!',
        database: 'MongoDB',
        user: {
          id: newUser._id,
          name: newUser.name,
          mobile: newUser.mobile,
          email: newUser.email,
          createdAt: newUser.createdAt,
        },
      });
    } else {
      // In-memory fallback
      const existing = inMemoryUsers.find((u) => u.email === trimmedEmail);
      if (existing) {
        return res.status(409).json({
          success: false,
          message: 'An account with this email address already exists. Please login.',
        });
      }

      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(cleanPassword, salt);
      const newUser: InMemoryUser = {
        id: 'mem_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
        name: trimmedName,
        mobile: trimmedMobile,
        email: trimmedEmail,
        password: hashedPassword,
        createdAt: new Date(),
      };

      inMemoryUsers.push(newUser);

      return res.status(201).json({
        success: true,
        message: 'User registered successfully!',
        database: 'In-Memory (Connect MongoDB via Docker or .env for permanent persistence)',
        user: {
          id: newUser.id,
          name: newUser.name,
          mobile: newUser.mobile,
          email: newUser.email,
          createdAt: newUser.createdAt,
        },
      });
    }
  } catch (error: any) {
    console.error('[Register Error]', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Server error while registering user.',
    });
  }
};

/**
 * Log in an existing user
 * POST /api/auth/login
 */
export const loginUser = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password.',
      });
    }

    const trimmedEmail = String(email).trim().toLowerCase();
    const cleanPassword = String(password);

    if (!isValidEmail(trimmedEmail)) {
      return res.status(400).json({
        success: false,
        message: 'Please enter a valid email address.',
      });
    }

    if (isDatabaseConnected()) {
      const user = await User.findOne({ email: trimmedEmail });
      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'Invalid email or password.',
        });
      }

      const isMatch = await user.comparePassword(cleanPassword);
      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message: 'Invalid email or password.',
        });
      }

      return res.status(200).json({
        success: true,
        message: 'Login successful! Welcome back.',
        database: 'MongoDB',
        user: {
          id: user._id,
          name: user.name,
          mobile: user.mobile,
          email: user.email,
          createdAt: user.createdAt,
        },
      });
    } else {
      // In-memory fallback check
      const user = inMemoryUsers.find((u) => u.email === trimmedEmail);
      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'Invalid email or password.',
        });
      }

      const isMatch = await bcrypt.compare(cleanPassword, user.password);
      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message: 'Invalid email or password.',
        });
      }

      return res.status(200).json({
        success: true,
        message: 'Login successful! Welcome back.',
        database: 'In-Memory (Connect MongoDB via Docker or .env for permanent persistence)',
        user: {
          id: user.id,
          name: user.name,
          mobile: user.mobile,
          email: user.email,
          createdAt: user.createdAt,
        },
      });
    }
  } catch (error: any) {
    console.error('[Login Error]', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Server error while logging in.',
    });
  }
};

/**
 * Health-check endpoint
 * GET /health
 */
export const getHealth = async (_req: Request, res: Response): Promise<Response> => {
  const dbConnected = isDatabaseConnected();
  return res.status(200).json({
    status: 'ok',
    message: 'Authentication REST API is running healthy',
    timestamp: new Date().toISOString(),
    uptime: Math.round(process.uptime()),
    database: {
      connected: dbConnected,
      type: dbConnected ? 'MongoDB (Mongoose)' : 'Fallback In-Memory Store',
      uri: process.env.MONGODB_URI ? '[Configured in .env]' : 'mongodb://127.0.0.1:27017/auth_db',
    },
  });
};

/**
 * List registered users (sensitive fields excluded) for validation & monitoring
 * GET /api/auth/users
 */
export const getUsers = async (_req: Request, res: Response): Promise<Response> => {
  try {
    if (isDatabaseConnected()) {
      const users = await User.find({}, '-password').sort({ createdAt: -1 });
      return res.status(200).json({
        success: true,
        count: users.length,
        database: 'MongoDB',
        users,
      });
    } else {
      const sanitized = inMemoryUsers.map(({ password, ...rest }) => rest);
      return res.status(200).json({
        success: true,
        count: sanitized.length,
        database: 'In-Memory Store',
        users: sanitized,
      });
    }
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch users.',
    });
  }
};

// Store active password reset tokens in memory: email -> { code, expiresAt }
const resetTokens: Map<string, { code: string; expiresAt: number }> = new Map();

/**
 * Request password reset
 * POST /api/auth/forgot-password
 */
export const forgotPassword = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({
        success: false,
        message: 'Please provide your registered email address.',
      });
    }

    const trimmedEmail = String(email).trim().toLowerCase();
    if (!isValidEmail(trimmedEmail)) {
      return res.status(400).json({
        success: false,
        message: 'Please enter a valid email address.',
      });
    }

    let userExists = false;
    if (isDatabaseConnected()) {
      const user = await User.findOne({ email: trimmedEmail });
      userExists = !!user;
    } else {
      userExists = inMemoryUsers.some((u) => u.email === trimmedEmail);
    }

    if (!userExists) {
      return res.status(404).json({
        success: false,
        message: 'No account found with this email address.',
      });
    }

    // Generate 6-digit verification code
    const resetCode = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = Date.now() + 15 * 60 * 1000; // 15 mins
    resetTokens.set(trimmedEmail, { code: resetCode, expiresAt });

    return res.status(200).json({
      success: true,
      message: `A 6-digit verification code has been dispatched to ${trimmedEmail}.`,
      resetCode, // provided so user can complete flow smoothly without external email server
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Error processing forgot password request.',
    });
  }
};

/**
 * Confirm password reset
 * POST /api/auth/reset-password
 */
export const resetPassword = async (req: Request, res: Response): Promise<Response> => {
  try {
    const { email, code, newPassword } = req.body;
    if (!email || !code || !newPassword) {
      return res.status(400).json({
        success: false,
        message: 'Email, verification code, and new password are required.',
      });
    }

    const trimmedEmail = String(email).trim().toLowerCase();
    const cleanPassword = String(newPassword);

    if (cleanPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'New password must be at least 6 characters long.',
      });
    }

    const record = resetTokens.get(trimmedEmail);
    if (!record || record.code !== String(code).trim() || Date.now() > record.expiresAt) {
      return res.status(400).json({
        success: false,
        message: 'Invalid or expired verification code. Please request a new one.',
      });
    }

    // Hash new password using bcrypt
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(cleanPassword, salt);

    if (isDatabaseConnected()) {
      const user = await User.findOne({ email: trimmedEmail });
      if (!user) {
        return res.status(404).json({ success: false, message: 'User not found.' });
      }
      user.password = hashedPassword;
      await user.save();
    } else {
      const user = inMemoryUsers.find((u) => u.email === trimmedEmail);
      if (user) {
        user.password = hashedPassword;
      }
    }

    // Invalidate reset code
    resetTokens.delete(trimmedEmail);

    return res.status(200).json({
      success: true,
      message: 'Password has been successfully reset! You can now log in with your new password.',
    });
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Error resetting password.',
    });
  }
};

