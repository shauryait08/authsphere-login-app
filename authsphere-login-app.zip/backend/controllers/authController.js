import bcrypt from 'bcryptjs';
import User from '../models/User.js';
import { isDatabaseConnected } from '../config/db.js';

const inMemoryUsers = [];

export const isValidEmail = (email) => {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(email).trim());
};

export const isValidMobile = (mobile) => {
  const cleaned = String(mobile).replace(/[\s\-\(\)\+]/g, '');
  return /^\d{10,15}$/.test(cleaned);
};

export const registerUser = async (req, res) => {
  try {
    const { name, mobile, email, password } = req.body;

    if (!name || !mobile || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'All fields (Name, Mobile, Email, Password) are required.',
      });
    }

    const trimmedName = String(name).trim();
    const trimmedMobile = String(mobile).trim();
    const trimmedEmail = String(email).trim().toLowerCase();
    const cleanPassword = String(password);

    if (trimmedName.length < 2) {
      return res.status(400).json({
        success: false,
        message: 'Name must be at least 2 characters long.',
      });
    }

    if (!isValidMobile(trimmedMobile)) {
      return res.status(400).json({
        success: false,
        message: 'Please provide a valid 10-to-15 digit mobile number.',
      });
    }

    if (!isValidEmail(trimmedEmail)) {
      return res.status(400).json({
        success: false,
        message: 'Please enter a valid email address (e.g. user@example.com).',
      });
    }

    if (cleanPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.',
      });
    }

    if (isDatabaseConnected()) {
      const existingUser = await User.findOne({ email: trimmedEmail });
      if (existingUser) {
        return res.status(409).json({
          success: false,
          message: 'An account with this email address already exists. Please login.',
        });
      }

      const newUser = new User({
        name: trimmedName,
        mobile: trimmedMobile,
        email: trimmedEmail,
        password: cleanPassword,
        createdAt: new Date(),
      });

      await newUser.save();

      return res.status(201).json({
        success: true,
        message: 'User registered successfully!',
        database: 'MongoDB',
        user: {
          id: newUser._id,
          name: newUser.name,
          mobile: newUser.mobile,
          email: newUser.email,
          createdAt: newUser.createdAt,
        },
      });
    } else {
      const existing = inMemoryUsers.find((u) => u.email === trimmedEmail);
      if (existing) {
        return res.status(409).json({
          success: false,
          message: 'An account with this email address already exists. Please login.',
        });
      }

      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(cleanPassword, salt);
      const newUser = {
        id: 'mem_' + Date.now().toString(36) + Math.random().toString(36).substring(2, 6),
        name: trimmedName,
        mobile: trimmedMobile,
        email: trimmedEmail,
        password: hashedPassword,
        createdAt: new Date(),
      };

      inMemoryUsers.push(newUser);

      return res.status(201).json({
        success: true,
        message: 'User registered successfully!',
        database: 'In-Memory Store',
        user: {
          id: newUser.id,
          name: newUser.name,
          mobile: newUser.mobile,
          email: newUser.email,
          createdAt: newUser.createdAt,
        },
      });
    }
  } catch (error) {
    console.error('[Register Error]', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Server error while registering user.',
    });
  }
};

export const loginUser = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password.',
      });
    }

    const trimmedEmail = String(email).trim().toLowerCase();
    const cleanPassword = String(password);

    if (!isValidEmail(trimmedEmail)) {
      return res.status(400).json({
        success: false,
        message: 'Please enter a valid email address.',
      });
    }

    if (isDatabaseConnected()) {
      const user = await User.findOne({ email: trimmedEmail });
      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'Invalid email or password.',
        });
      }

      const isMatch = await user.comparePassword(cleanPassword);
      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message: 'Invalid email or password.',
        });
      }

      return res.status(200).json({
        success: true,
        message: 'Login successful! Welcome back.',
        database: 'MongoDB',
        user: {
          id: user._id,
          name: user.name,
          mobile: user.mobile,
          email: user.email,
          createdAt: user.createdAt,
        },
      });
    } else {
      const user = inMemoryUsers.find((u) => u.email === trimmedEmail);
      if (!user) {
        return res.status(401).json({
          success: false,
          message: 'Invalid email or password.',
        });
      }

      const isMatch = await bcrypt.compare(cleanPassword, user.password);
      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message: 'Invalid email or password.',
        });
      }

      return res.status(200).json({
        success: true,
        message: 'Login successful! Welcome back.',
        database: 'In-Memory Store',
        user: {
          id: user.id,
          name: user.name,
          mobile: user.mobile,
          email: user.email,
          createdAt: user.createdAt,
        },
      });
    }
  } catch (error) {
    console.error('[Login Error]', error);
    return res.status(500).json({
      success: false,
      message: error.message || 'Server error while logging in.',
    });
  }
};

export const getHealth = async (_req, res) => {
  const dbConnected = isDatabaseConnected();
  return res.status(200).json({
    status: 'ok',
    message: 'Authentication REST API is running healthy',
    timestamp: new Date().toISOString(),
    uptime: Math.round(process.uptime()),
    database: {
      connected: dbConnected,
      type: dbConnected ? 'MongoDB (Mongoose)' : 'Fallback In-Memory Store',
      uri: process.env.MONGODB_URI ? '[Configured in .env]' : 'mongodb://127.0.0.1:27017/auth_db',
    },
  });
};

export const getUsers = async (_req, res) => {
  try {
    if (isDatabaseConnected()) {
      const users = await User.find({}, '-password').sort({ createdAt: -1 });
      return res.status(200).json({
        success: true,
        count: users.length,
        database: 'MongoDB',
        users,
      });
    } else {
      const sanitized = inMemoryUsers.map(({ password, ...rest }) => rest);
      return res.status(200).json({
        success: true,
        count: sanitized.length,
        database: 'In-Memory Store',
        users: sanitized,
      });
    }
  } catch (error) {
    return res.status(500).json({
      success: false,
      message: error.message || 'Failed to fetch users.',
    });
  }
};
