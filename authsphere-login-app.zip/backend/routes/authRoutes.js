import { Router } from 'express';
import {
  registerUser,
  loginUser,
  getHealth,
  getUsers,
} from '../controllers/authController.js';

const router = Router();

// Registration endpoint: POST /api/auth/register
router.post('/register', registerUser);

// Login endpoint: POST /api/auth/login
router.post('/login', loginUser);

// User list endpoint (passwords excluded): GET /api/auth/users
router.get('/users', getUsers);

// Health check endpoint: GET /api/auth/health
router.get('/health', getHealth);

export default router;
