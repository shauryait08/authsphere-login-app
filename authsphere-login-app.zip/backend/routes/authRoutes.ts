import { Router } from 'express';
import {
  registerUser,
  loginUser,
  getHealth,
  getUsers,
  forgotPassword,
  resetPassword,
} from '../controllers/authController';

const router = Router();

// Registration endpoint: POST /api/auth/register
router.post('/register', registerUser);

// Login endpoint: POST /api/auth/login
router.post('/login', loginUser);

// Forgot Password endpoint: POST /api/auth/forgot-password
router.post('/forgot-password', forgotPassword);

// Reset Password endpoint: POST /api/auth/reset-password
router.post('/reset-password', resetPassword);

// User list endpoint (passwords excluded): GET /api/auth/users
router.get('/users', getUsers);

// Health check endpoint: GET /api/auth/health
router.get('/health', getHealth);

export default router;

