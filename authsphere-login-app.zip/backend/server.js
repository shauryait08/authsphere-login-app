import express from 'express';
import dotenv from 'dotenv';
import { connectDB } from './config/db.js';
import authRoutes from './routes/authRoutes.js';
import { getHealth } from './controllers/authController.js';

// Load environment variables
dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Body parsing middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Connect to MongoDB
connectDB();

// Health check endpoint (explicitly required: GET /health)
app.get('/health', getHealth);

// Authentication REST APIs
app.use('/api/auth', authRoutes);
app.use('/api', authRoutes);

// Root fallback informational route
app.get('/', (_req, res) => {
  res.json({
    message: 'AuthSphere REST API is active',
    endpoints: {
      health: 'GET /health',
      register: 'POST /api/auth/register',
      login: 'POST /api/auth/login',
      users: 'GET /api/auth/users',
    },
  });
});

// Start Express server
const server = app.listen(PORT, () => {
  console.log(`[Backend] Auth server listening on http://localhost:${PORT}`);
});

export default app;
