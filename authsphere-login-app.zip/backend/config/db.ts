import mongoose from 'mongoose';

let isConnected = false;

export const connectDB = async (): Promise<boolean> => {
  const mongoUri = process.env.MONGODB_URI || process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/auth_db';

  try {
    // Attempt connection with short timeout so it doesn't hang if Mongo isn't running
    await mongoose.connect(mongoUri, {
      serverSelectionTimeoutMS: 2500,
    });
    isConnected = true;
    console.log(`[MongoDB] Connected successfully to ${mongoUri}`);
    return true;
  } catch (error: any) {
    isConnected = false;
    console.warn(`[MongoDB] Notice: Could not connect to MongoDB at ${mongoUri}. (${error.message})`);
    console.warn('[MongoDB] Running in safe fallback mode. If running via Docker Compose, MongoDB will be connected automatically.');
    return false;
  }
};

export const isDatabaseConnected = (): boolean => {
  return isConnected && mongoose.connection.readyState === 1;
};

mongoose.connection.on('connected', () => {
  isConnected = true;
  console.log('[MongoDB] Connection state: Connected');
});

mongoose.connection.on('disconnected', () => {
  isConnected = false;
  console.warn('[MongoDB] Connection state: Disconnected');
});

mongoose.connection.on('error', (err) => {
  isConnected = false;
  console.error('[MongoDB] Connection error:', err.message);
});
