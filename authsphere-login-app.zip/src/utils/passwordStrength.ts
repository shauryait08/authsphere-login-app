import { PasswordStrength } from '../types/auth';

export function calculatePasswordStrength(password: string): PasswordStrength {
  if (!password) {
    return {
      score: 0,
      label: 'Very Weak',
      color: 'bg-slate-700',
      hasMinLength: false,
      hasUpper: false,
      hasNumber: false,
      hasSpecial: false,
    };
  }

  const hasMinLength = password.length >= 8;
  const hasUpper = /[A-Z]/.test(password);
  const hasNumber = /[0-9]/.test(password);
  const hasSpecial = /[^A-Za-z0-9]/.test(password);

  let score = 0;
  if (password.length >= 6) score += 1;
  if (hasMinLength) score += 1;
  if (hasUpper && (hasNumber || hasSpecial)) score += 1;
  if (hasUpper && hasNumber && hasSpecial && password.length >= 10) score += 1;

  let label: PasswordStrength['label'] = 'Very Weak';
  let color = 'bg-rose-500';

  switch (score) {
    case 1:
      label = 'Weak';
      color = 'bg-rose-500';
      break;
    case 2:
      label = 'Fair';
      color = 'bg-amber-500';
      break;
    case 3:
      label = 'Strong';
      color = 'bg-purple-500';
      break;
    case 4:
      label = 'Excellent';
      color = 'bg-emerald-400';
      break;
    default:
      label = 'Very Weak';
      color = 'bg-rose-500';
  }

  return {
    score,
    label,
    color,
    hasMinLength,
    hasUpper,
    hasNumber,
    hasSpecial,
  };
}
