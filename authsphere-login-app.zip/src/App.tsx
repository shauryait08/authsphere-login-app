import React, { useEffect, useState } from 'react';
import { Navbar } from './components/Navbar';
import { LoginForm } from './components/LoginForm';
import { RegisterForm } from './components/RegisterForm';
import { UserProfile } from './components/UserProfile';
import { SystemHealth } from './components/SystemHealth';
import { DatabaseViewer } from './components/DatabaseViewer';
import { DevOpsDocsModal } from './components/DevOpsDocsModal';
import { ForgotPasswordModal } from './components/ForgotPasswordModal';
import { fetchHealthApi } from './services/api';
import { User, HealthResponse } from './types/auth';
import { ShieldCheck, Database, Lock, Server } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<'auth' | 'health' | 'database' | 'docs'>('auth');
  const [authSubView, setAuthSubView] = useState<'login' | 'register'>('login');
  const [isForgotModalOpen, setIsForgotModalOpen] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [health, setHealth] = useState<HealthResponse | null>(null);
  const [healthLoading, setHealthLoading] = useState(false);

  const checkHealth = async () => {
    setHealthLoading(true);
    try {
      const data = await fetchHealthApi();
      if (data) {
        setHealth(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setHealthLoading(false);
    }
  };

  useEffect(() => {
    checkHealth();
    const interval = setInterval(checkHealth, 30000);
    return () => clearInterval(interval);
  }, []);

  const handleAuthSuccess = (user: User) => {
    setCurrentUser(user);
    checkHealth();
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setAuthSubView('login');
  };

  return (
    <div className="min-h-screen bg-[#080b14] text-slate-100 flex flex-col font-sans selection:bg-purple-500 selection:text-white antialiased relative overflow-hidden">
      {/* Background Ambient Glowing Gradient Orbs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden z-0">
        <div className="absolute -top-32 -left-32 w-[550px] h-[550px] bg-purple-700/20 rounded-full blur-[140px] animate-orb-1" />
        <div className="absolute top-1/3 -right-32 w-[600px] h-[600px] bg-pink-600/15 rounded-full blur-[160px] animate-orb-2" />
        <div className="absolute -bottom-32 left-1/4 w-[500px] h-[500px] bg-indigo-700/20 rounded-full blur-[150px] animate-pulse-glow" />
      </div>

      {/* Top Bar with AuthSphere Branding */}
      <div className="relative z-30">
        <Navbar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          isDbConnected={health?.database.connected ?? null}
        />
      </div>

      {/* Main Content Area */}
      <main className="relative z-10 flex-1 max-w-6xl w-full mx-auto px-4 sm:px-6 py-8 sm:py-12 flex flex-col justify-center">
        {activeTab === 'auth' && (
          <div className="space-y-8">
            {currentUser ? (
              <UserProfile
                user={currentUser}
                onLogout={handleLogout}
                onRegisterAnother={() => {
                  setCurrentUser(null);
                  setAuthSubView('register');
                }}
                onViewDatabase={() => setActiveTab('database')}
                onOpenDocs={() => setActiveTab('docs')}
              />
            ) : (
              <div className="space-y-6">
                {/* View Switcher Pills */}
                <div className="flex justify-center">
                  <div className="inline-flex rounded-2xl bg-[#0e1428]/80 p-1.5 border border-purple-500/25 backdrop-blur-xl shadow-lg">
                    <button
                      type="button"
                      onClick={() => setAuthSubView('login')}
                      className={`px-6 py-2 text-xs sm:text-sm font-semibold rounded-xl transition-all cursor-pointer ${
                        authSubView === 'login'
                          ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md shadow-purple-600/30'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Sign In
                    </button>
                    <button
                      type="button"
                      onClick={() => setAuthSubView('register')}
                      className={`px-6 py-2 text-xs sm:text-sm font-semibold rounded-xl transition-all cursor-pointer ${
                        authSubView === 'register'
                          ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-md shadow-purple-600/30'
                          : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      Join AuthSphere
                    </button>
                  </div>
                </div>

                {/* Login or Register Form */}
                {authSubView === 'login' ? (
                  <LoginForm
                    onSuccess={handleAuthSuccess}
                    onSwitchToRegister={() => setAuthSubView('register')}
                    onForgotPassword={() => setIsForgotModalOpen(true)}
                    onRefreshHealth={checkHealth}
                  />
                ) : (
                  <RegisterForm
                    onSuccess={handleAuthSuccess}
                    onSwitchToLogin={() => setAuthSubView('login')}
                    onRefreshHealth={checkHealth}
                  />
                )}

                {/* Architecture Highlights Callouts */}
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 max-w-2xl mx-auto pt-6 border-t border-purple-900/30 text-xs">
                  <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-[#0c1224]/60 border border-purple-900/40 backdrop-blur-md">
                    <Lock className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-white block">Bcrypt Encryption</span>
                      <span className="text-slate-400 text-[11px]">Zero plaintext passwords stored</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-[#0c1224]/60 border border-purple-900/40 backdrop-blur-md">
                    <Database className="w-4 h-4 text-pink-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-white block">MongoDB Mongoose</span>
                      <span className="text-slate-400 text-[11px]">Validated schema &amp; unique emails</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-[#0c1224]/60 border border-purple-900/40 backdrop-blur-md">
                    <Server className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
                    <div>
                      <span className="font-semibold text-white block">REST API &amp; Docker</span>
                      <span className="text-slate-400 text-[11px]">Health-check &amp; EC2 deployment</span>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {activeTab === 'health' && (
          <SystemHealth
            health={health}
            loading={healthLoading}
            onRefresh={checkHealth}
          />
        )}

        {activeTab === 'database' && (
          <DatabaseViewer
            onSelectUserToLogin={(email) => {
              setActiveTab('auth');
              setAuthSubView('login');
            }}
          />
        )}

        {activeTab === 'docs' && <DevOpsDocsModal />}
      </main>

      {/* Forgot Password Modal */}
      <ForgotPasswordModal
        isOpen={isForgotModalOpen}
        onClose={() => setIsForgotModalOpen(false)}
        onSuccess={() => {
          setAuthSubView('login');
        }}
      />

      {/* Quiet Footer */}
      <footer className="relative z-10 w-full border-t border-purple-900/30 bg-[#070a13]/80 backdrop-blur-md py-6 text-xs text-slate-500">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-slate-300 font-semibold">AuthSphere</span>
            <span aria-hidden="true" className="text-purple-600">·</span>
            <span>Modern Authentication &amp; Identity Platform</span>
          </div>

          <div className="flex flex-wrap items-center gap-4 text-slate-400 font-mono text-[11px]">
            <span>GET /health</span>
            <span aria-hidden="true" className="text-purple-600">·</span>
            <span>POST /api/auth/register</span>
            <span aria-hidden="true" className="text-purple-600">·</span>
            <span>POST /api/auth/login</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
