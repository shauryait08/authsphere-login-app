export interface User {
  id?: string;
  _id?: string;
  name: string;
  mobile: string;
  email: string;
  createdAt: string | Date;
}

export interface AuthResponse {
  success: boolean;
  message: string;
  database?: string;
  user?: User;
  resetCode?: string;
}

export interface HealthResponse {
  status: string;
  message: string;
  timestamp: string;
  uptime: number;
  database: {
    connected: boolean;
    type: string;
    uri: string;
  };
}

export interface ValidationErrors {
  name?: string;
  mobile?: string;
  email?: string;
  password?: string;
  confirmPassword?: string;
  terms?: string;
  code?: string;
  general?: string;
}

export interface PasswordStrength {
  score: number; // 0 to 4
  label: 'Very Weak' | 'Weak' | 'Fair' | 'Strong' | 'Excellent';
  color: string;
  hasMinLength: boolean;
  hasUpper: boolean;
  hasNumber: boolean;
  hasSpecial: boolean;
}

