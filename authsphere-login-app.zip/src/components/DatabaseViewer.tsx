import React, { useEffect, useState } from 'react';
import {
  Database,
  RefreshCw,
  Calendar,
  Phone,
  Mail,
  Lock,
  User as UserIcon,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { fetchUsersApi } from '../services/api';
import { User } from '../types/auth';

interface DatabaseViewerProps {
  onSelectUserToLogin?: (email: string) => void;
}

export const DatabaseViewer: React.FC<DatabaseViewerProps> = ({
  onSelectUserToLogin,
}) => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(false);
  const [databaseType, setDatabaseType] = useState<string>('MongoDB');

  const loadUsers = async () => {
    setLoading(true);
    try {
      const res = await fetchUsersApi();
      if (res.success && res.users) {
        setUsers(res.users);
        if (res.database) setDatabaseType(res.database);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="glass-panel-elevated rounded-3xl p-6 sm:p-8 backdrop-blur-xl border border-purple-500/25">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-purple-900/40">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
                <Database className="w-5 h-5" />
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
                MongoDB Document Records
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Live queries executed on Mongoose schema with bcrypt-hashed passwords.
            </p>
          </div>
          <div className="flex items-center gap-3">
            <div className="px-3 py-1.5 rounded-xl bg-[#080c18] border border-purple-900/40 text-xs font-mono text-purple-200">
              Provider: <span className="text-pink-400 font-semibold">{databaseType}</span>
            </div>
            <button
              onClick={loadUsers}
              disabled={loading}
              className="px-4 py-2 bg-purple-600/20 hover:bg-purple-600/40 border border-purple-500/30 text-purple-200 text-xs font-medium rounded-xl transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <RefreshCw className={`w-3.5 h-3.5 text-purple-400 ${loading ? 'animate-spin' : ''}`} />
              <span>Refresh</span>
            </button>
          </div>
        </div>

        {/* Schema Requirement Compliance Banner */}
        <div className="mt-6 p-4 bg-[#090d1a] border border-purple-900/40 rounded-2xl">
          <div className="flex items-center gap-2 text-xs font-semibold text-purple-300 mb-2.5">
            <Layers className="w-4 h-4 text-purple-400" />
            <span>Mongoose Collection Schema: <code className="text-pink-400">users</code></span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5 text-[11px] font-mono">
            <div className="p-2.5 bg-[#0e1428] rounded-xl border border-purple-900/30">
              <span className="text-purple-300 block font-semibold">name</span>
              <span className="text-slate-400">String (trim, min 2)</span>
            </div>
            <div className="p-2.5 bg-[#0e1428] rounded-xl border border-purple-900/30">
              <span className="text-purple-300 block font-semibold">mobile</span>
              <span className="text-slate-400">String (10-15 digits)</span>
            </div>
            <div className="p-2.5 bg-[#0e1428] rounded-xl border border-purple-900/30">
              <span className="text-purple-300 block font-semibold">email</span>
              <span className="text-slate-400">String (unique)</span>
            </div>
            <div className="p-2.5 bg-[#0e1428] rounded-xl border border-purple-900/30">
              <span className="text-pink-400 block font-semibold">password</span>
              <span className="text-slate-400">bcrypt (10 rounds)</span>
            </div>
            <div className="p-2.5 bg-[#0e1428] rounded-xl border border-purple-900/30">
              <span className="text-purple-300 block font-semibold">createdAt</span>
              <span className="text-slate-400">Date (default: now)</span>
            </div>
          </div>
        </div>
      </div>

      {/* Users List */}
      <div className="glass-panel rounded-3xl p-6 sm:p-8 border border-purple-500/20">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-semibold text-white">
            Stored Documents in Database ({users.length})
          </h3>
          <span className="text-xs text-purple-300/70 font-mono">
            Plain-text passwords never stored
          </span>
        </div>

        {users.length === 0 ? (
          <div className="text-center py-12 border border-dashed border-purple-900/40 rounded-2xl">
            <UserIcon className="w-10 h-10 text-purple-400/50 mx-auto mb-3" />
            <p className="text-sm font-medium text-slate-200">
              No registered user documents yet
            </p>
            <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
              Use the "Auth Portal" tab to register your first user with Name, Mobile, Email, and Password!
            </p>
          </div>
        ) : (
          <div className="space-y-3">
            {users.map((u, index) => {
              const formattedDate = u.createdAt
                ? new Date(u.createdAt).toLocaleString(undefined, {
                    dateStyle: 'medium',
                    timeStyle: 'short',
                  })
                : 'Recent';

              return (
                <div
                  key={u.id || u._id || index}
                  className="p-4 bg-[#0a0e1c] border border-purple-900/30 rounded-2xl hover:border-purple-500/40 transition-colors flex flex-col md:flex-row md:items-center justify-between gap-4"
                >
                  <div className="space-y-1.5 flex-1 min-w-0">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-300 text-xs font-bold">
                        {u.name ? u.name.charAt(0).toUpperCase() : 'U'}
                      </div>
                      <span className="text-sm font-semibold text-white truncate">
                        {u.name}
                      </span>
                      <span className="text-[10px] font-mono text-slate-500 ml-1">
                        ID: {String(u.id || u._id || '').substring(0, 10)}...
                      </span>
                    </div>

                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-slate-400">
                      <span className="flex items-center gap-1.5">
                        <Mail className="w-3.5 h-3.5 text-purple-400" />
                        <span className="text-slate-300">{u.email}</span>
                      </span>
                      <span className="flex items-center gap-1.5 font-mono">
                        <Phone className="w-3.5 h-3.5 text-pink-400" />
                        <span className="text-slate-300">{u.mobile}</span>
                      </span>
                      <span className="flex items-center gap-1.5 text-slate-400">
                        <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                        <span className="tabular-nums">{formattedDate}</span>
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 self-start md:self-center shrink-0">
                    <div className="px-2.5 py-1 rounded-lg bg-[#060912] border border-purple-900/40 text-[11px] font-mono text-pink-300 flex items-center gap-1.5">
                      <Lock className="w-3 h-3 text-pink-400" />
                      <span>$2a$10$hashed</span>
                    </div>
                    {onSelectUserToLogin && (
                      <button
                        onClick={() => onSelectUserToLogin(u.email)}
                        className="px-3 py-1 bg-purple-600/30 hover:bg-purple-600/50 border border-purple-500/30 text-purple-200 text-xs font-medium rounded-lg transition-colors cursor-pointer flex items-center gap-1"
                      >
                        <span>Sign In</span>
                        <ArrowRight className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
