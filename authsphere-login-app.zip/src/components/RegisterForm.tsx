import React, { useState } from 'react';
import { Eye, EyeOff, Loader2, AlertCircle, CheckCircle2, Sparkles, Check, X } from 'lucide-react';
import { registerApi } from '../services/api';
import { User, ValidationErrors } from '../types/auth';
import { calculatePasswordStrength } from '../utils/passwordStrength';

interface RegisterFormProps {
  onSuccess: (user: User) => void;
  onSwitchToLogin: () => void;
  onRefreshHealth: () => void;
}

export const RegisterForm: React.FC<RegisterFormProps> = ({
  onSuccess,
  onSwitchToLogin,
  onRefreshHealth,
}) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [acceptedTerms, setAcceptedTerms] = useState(true);

  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [serverAlert, setServerAlert] = useState<{
    type: 'error' | 'success';
    message: string;
  } | null>(null);

  // Live password strength calculation
  const strength = calculatePasswordStrength(password);

  const validate = (): boolean => {
    const newErrors: ValidationErrors = {};

    if (!name.trim()) {
      newErrors.name = 'Full name is required.';
    } else if (name.trim().length < 2) {
      newErrors.name = 'Name must be at least 2 characters.';
    }

    if (!email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      newErrors.email = 'Please enter a valid email address.';
    }

    const cleanMobile = mobile.replace(/[\s\-\(\)\+]/g, '');
    if (!mobile.trim()) {
      newErrors.mobile = 'Mobile number is required.';
    } else if (!/^\d{10,15}$/.test(cleanMobile)) {
      newErrors.mobile = 'Please enter a valid 10-15 digit mobile number.';
    }

    if (!password) {
      newErrors.password = 'Password is required.';
    } else if (password.length < 8) {
      newErrors.password = 'Password must be at least 8 characters long.';
    }

    if (password !== confirmPassword) {
      newErrors.confirmPassword = 'Passwords do not match.';
    }

    if (!acceptedTerms) {
      newErrors.terms = 'You must accept the Terms of Service & Privacy Policy.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setServerAlert(null);

    if (!validate()) return;

    setLoading(true);
    try {
      const response = await registerApi({
        name: name.trim(),
        mobile: mobile.trim(),
        email: email.trim().toLowerCase(),
        password,
      });

      if (response.success && response.user) {
        setServerAlert({
          type: 'success',
          message: response.message || 'Account successfully created and registered with MongoDB!',
        });
        onRefreshHealth();
        setTimeout(() => {
          onSuccess(response.user!);
        }, 600);
      } else {
        setServerAlert({
          type: 'error',
          message: response.message || 'Registration failed. Please check your information.',
        });
      }
    } catch (err: any) {
      setServerAlert({
        type: 'error',
        message: err.message || 'Could not connect to the registration server.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFillDemo = () => {
    const random = Math.floor(100 + Math.random() * 900);
    setName('Alex Mercer');
    setEmail(`alex.mercer${random}@example.com`);
    setMobile(`+1 (555) 019-${random}`);
    setPassword('AuthSphere#2026');
    setConfirmPassword('AuthSphere#2026');
    setAcceptedTerms(true);
    setErrors({});
    setServerAlert(null);
  };

  return (
    <div className="w-full max-w-[440px] mx-auto">
      {/* Centered Glass Card styled exactly like reference image_c9a21231.png */}
      <div className="glass-panel-elevated rounded-[28px] p-7 sm:p-9 shadow-2xl relative overflow-hidden backdrop-blur-2xl transition-all border border-purple-500/25">
        {/* Ambient top light glow */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-64 h-32 bg-purple-600/30 blur-3xl pointer-events-none rounded-full" />

        {/* Header matching image_c9a21231.png */}
        <div className="mb-6 text-center relative z-10">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display">
            Join us in a Snap
          </h2>
          <p className="text-xs sm:text-sm text-purple-200/70 mt-1">
            Create your account secured with MongoDB &amp; bcrypt
          </p>
        </div>

        {/* Server Alert Message */}
        {serverAlert && (
          <div
            className={`mb-5 p-3.5 rounded-xl border flex items-start gap-2.5 text-xs sm:text-sm transition-all relative z-10 ${
              serverAlert.type === 'error'
                ? 'bg-rose-500/15 border-rose-500/30 text-rose-200'
                : 'bg-emerald-500/15 border-emerald-500/30 text-emerald-200'
            }`}
          >
            {serverAlert.type === 'error' ? (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
            ) : (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
            )}
            <span className="leading-snug">{serverAlert.message}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 relative z-10" noValidate>
          {/* Full Name */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Full Name
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => {
                setName(e.target.value);
                if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
              }}
              placeholder="John Doe"
              className={`w-full px-4 py-3 glass-input rounded-2xl text-sm text-white placeholder-slate-500 focus:outline-none transition-all ${
                errors.name ? 'border-rose-500/60' : ''
              }`}
            />
            {errors.name && (
              <p className="text-[11px] text-rose-400 mt-1 pl-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                {errors.name}
              </p>
            )}
          </div>

          {/* Email Address */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Email Address
            </label>
            <input
              type="email"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                if (errors.email) setErrors((prev) => ({ ...prev, email: undefined }));
              }}
              placeholder="example@site.com"
              className={`w-full px-4 py-3 glass-input rounded-2xl text-sm text-white placeholder-slate-500 focus:outline-none transition-all ${
                errors.email ? 'border-rose-500/60' : ''
              }`}
            />
            {errors.email && (
              <p className="text-[11px] text-rose-400 mt-1 pl-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                {errors.email}
              </p>
            )}
          </div>

          {/* Mobile Number */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Mobile Number
            </label>
            <input
              type="tel"
              value={mobile}
              onChange={(e) => {
                setMobile(e.target.value);
                if (errors.mobile) setErrors((prev) => ({ ...prev, mobile: undefined }));
              }}
              placeholder="+1 (555) 019-2834"
              className={`w-full px-4 py-3 glass-input rounded-2xl text-sm text-white placeholder-slate-500 focus:outline-none transition-all ${
                errors.mobile ? 'border-rose-500/60' : ''
              }`}
            />
            {errors.mobile && (
              <p className="text-[11px] text-rose-400 mt-1 pl-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                {errors.mobile}
              </p>
            )}
          </div>

          {/* Password */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-medium text-slate-300">
                Password
              </label>
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="text-xs text-purple-400 hover:text-purple-300 transition-colors cursor-pointer"
              >
                {showPassword ? 'hide' : 'show'}
              </button>
            </div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errors.password) setErrors((prev) => ({ ...prev, password: undefined }));
                }}
                placeholder="Minimum 8 characters"
                className={`w-full pl-4 pr-11 py-3 glass-input rounded-2xl text-sm text-white placeholder-slate-500 focus:outline-none transition-all ${
                  errors.password ? 'border-rose-500/60' : ''
                }`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-purple-300 transition-colors cursor-pointer"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>

            {/* Password strength visual indicator */}
            {password.length > 0 && (
              <div className="mt-2 space-y-1.5">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-slate-400">Strength:</span>
                  <span className={`font-semibold ${
                    strength.score <= 1 ? 'text-rose-400' :
                    strength.score === 2 ? 'text-amber-400' :
                    strength.score === 3 ? 'text-purple-400' : 'text-emerald-400'
                  }`}>
                    {strength.label}
                  </span>
                </div>
                {/* 4 strength segments */}
                <div className="grid grid-cols-4 gap-1.5 h-1.5">
                  <div className={`rounded-full h-full transition-all ${strength.score >= 1 ? strength.color : 'bg-slate-800'}`} />
                  <div className={`rounded-full h-full transition-all ${strength.score >= 2 ? strength.color : 'bg-slate-800'}`} />
                  <div className={`rounded-full h-full transition-all ${strength.score >= 3 ? strength.color : 'bg-slate-800'}`} />
                  <div className={`rounded-full h-full transition-all ${strength.score >= 4 ? strength.color : 'bg-slate-800'}`} />
                </div>
                <div className="grid grid-cols-2 gap-x-2 gap-y-1 text-[10px] text-slate-400 pt-1">
                  <span className={`flex items-center gap-1 ${strength.hasMinLength ? 'text-purple-300' : ''}`}>
                    {strength.hasMinLength ? <Check className="w-3 h-3 text-emerald-400" /> : <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />}
                    8+ chars
                  </span>
                  <span className={`flex items-center gap-1 ${strength.hasUpper ? 'text-purple-300' : ''}`}>
                    {strength.hasUpper ? <Check className="w-3 h-3 text-emerald-400" /> : <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />}
                    Uppercase
                  </span>
                  <span className={`flex items-center gap-1 ${strength.hasNumber ? 'text-purple-300' : ''}`}>
                    {strength.hasNumber ? <Check className="w-3 h-3 text-emerald-400" /> : <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />}
                    Number
                  </span>
                  <span className={`flex items-center gap-1 ${strength.hasSpecial ? 'text-purple-300' : ''}`}>
                    {strength.hasSpecial ? <Check className="w-3 h-3 text-emerald-400" /> : <span className="w-1.5 h-1.5 rounded-full bg-slate-600" />}
                    Special char
                  </span>
                </div>
              </div>
            )}

            {errors.password && (
              <p className="text-[11px] text-rose-400 mt-1 pl-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                {errors.password}
              </p>
            )}
          </div>

          {/* Confirm Password */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Confirm Password
            </label>
            <div className="relative">
              <input
                type={showConfirmPassword ? 'text' : 'password'}
                value={confirmPassword}
                onChange={(e) => {
                  setConfirmPassword(e.target.value);
                  if (errors.confirmPassword) setErrors((prev) => ({ ...prev, confirmPassword: undefined }));
                }}
                placeholder="Minimum 8 characters"
                className={`w-full pl-4 pr-11 py-3 glass-input rounded-2xl text-sm text-white placeholder-slate-500 focus:outline-none transition-all ${
                  errors.confirmPassword ? 'border-rose-500/60' : ''
                }`}
              />
              <button
                type="button"
                onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-purple-300 transition-colors cursor-pointer"
                aria-label={showConfirmPassword ? 'Hide password' : 'Show password'}
              >
                {showConfirmPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
            {errors.confirmPassword && (
              <p className="text-[11px] text-rose-400 mt-1 pl-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                {errors.confirmPassword}
              </p>
            )}
          </div>

          {/* Terms Toggle Switch matching screenshot image_c9a21231.png */}
          <div className="pt-2">
            <label className="flex items-start gap-3 cursor-pointer select-none">
              <button
                type="button"
                role="switch"
                aria-checked={acceptedTerms}
                onClick={() => {
                  setAcceptedTerms(!acceptedTerms);
                  if (errors.terms) setErrors((prev) => ({ ...prev, terms: undefined }));
                }}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  acceptedTerms ? 'bg-purple-600' : 'bg-slate-700'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow-lg ring-0 transition duration-200 ease-in-out ${
                    acceptedTerms ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
              <span className="text-xs text-slate-300 leading-snug">
                Accept our{' '}
                <span className="text-purple-400 hover:underline cursor-pointer">Terms of Service</span>
                {' '}and{' '}
                <span className="text-purple-400 hover:underline cursor-pointer">Privacy Policy</span>.
              </span>
            </label>
            {errors.terms && (
              <p className="text-[11px] text-rose-400 mt-1 pl-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                {errors.terms}
              </p>
            )}
          </div>

          {/* Submit Button ("Begin Your Journey") matching screenshot */}
          <button
            type="submit"
            disabled={loading}
            className="w-full mt-3 py-3.5 px-5 btn-purple-solid text-white font-bold rounded-2xl text-base transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Hashing &amp; Registering...</span>
              </>
            ) : (
              <span>Begin Your Journey</span>
            )}
          </button>
        </form>

        {/* Link to Login */}
        <div className="mt-6 text-center text-xs text-slate-400">
          <span>Already registered? </span>
          <button
            type="button"
            onClick={onSwitchToLogin}
            className="text-purple-400 hover:text-purple-300 font-semibold transition-colors cursor-pointer underline-offset-2 hover:underline"
          >
            Sign In
          </button>
        </div>

        {/* Quick demo autofill helper */}
        <div className="mt-5 pt-4 border-t border-purple-900/30 flex items-center justify-between text-[11px] text-slate-400">
          <span>Fast test account?</span>
          <button
            type="button"
            onClick={handleFillDemo}
            className="text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3 h-3 text-pink-400" />
            <span>Generate Test Data</span>
          </button>
        </div>
      </div>
    </div>
  );
};
