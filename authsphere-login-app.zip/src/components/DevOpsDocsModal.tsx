import React, { useState } from 'react';
import {
  Terminal,
  Copy,
  Check,
  Server,
  Database,
  Cloud,
  FileCode,
} from 'lucide-react';

export const DevOpsDocsModal: React.FC = () => {
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 1800);
  };

  const sections = [
    {
      title: '1. Local Development Commands',
      desc: 'Commands to install dependencies and run the application locally on your machine.',
      commands: [
        {
          label: 'Install Dependencies',
          cmd: 'npm install',
        },
        {
          label: 'Run Full-Stack App (Vite Dev + Express API on Port 3000)',
          cmd: 'npm run dev',
        },
        {
          label: 'Run Standalone Node.js Backend Server (Port 5000)',
          cmd: 'node backend/server.js',
        },
        {
          label: 'Build Production Frontend Bundle',
          cmd: 'npm run build',
        },
      ],
    },
    {
      title: '2. Docker & Docker Compose Commands',
      desc: 'Run the complete fullstack application and MongoDB container in one command.',
      commands: [
        {
          label: 'Build Application Docker Image',
          cmd: 'docker build -t authsphere-app .',
        },
        {
          label: 'Run Docker Compose (App + MongoDB 6.0)',
          cmd: 'docker compose up --build -d',
        },
        {
          label: 'View Live Container Logs',
          cmd: 'docker compose logs -f',
        },
        {
          label: 'Stop Containers',
          cmd: 'docker compose stop',
        },
        {
          label: 'Remove Containers and Network',
          cmd: 'docker compose down',
        },
        {
          label: 'Remove Containers, Networks & Database Volumes',
          cmd: 'docker compose down -v',
        },
      ],
    },
    {
      title: '3. API Health & Testing Commands (cURL)',
      desc: 'Execute direct cURL requests to test the REST endpoints against the server.',
      commands: [
        {
          label: 'Health Check (GET /health)',
          cmd: 'curl -X GET http://localhost:3000/health',
        },
        {
          label: 'User Registration (POST /api/auth/register)',
          cmd: `curl -X POST http://localhost:3000/api/auth/register \\
  -H "Content-Type: application/json" \\
  -d '{"name":"John Doe","mobile":"9876543210","email":"john@example.com","password":"mypassword123"}'`,
        },
        {
          label: 'User Login (POST /api/auth/login)',
          cmd: `curl -X POST http://localhost:3000/api/auth/login \\
  -H "Content-Type: application/json" \\
  -d '{"email":"john@example.com","password":"mypassword123"}'`,
        },
        {
          label: 'Forgot Password (POST /api/auth/forgot-password)',
          cmd: `curl -X POST http://localhost:3000/api/auth/forgot-password \\
  -H "Content-Type: application/json" \\
  -d '{"email":"john@example.com"}'`,
        },
      ],
    },
    {
      title: '4. AWS EC2 Deployment Guide',
      desc: 'Simple steps to deploy on an Ubuntu AWS EC2 instance.',
      commands: [
        {
          label: '1. Connect to EC2 via SSH',
          cmd: 'ssh -i "your-key.pem" ubuntu@<ec2-public-ip>',
        },
        {
          label: '2. Install Docker & Docker Compose on Ubuntu',
          cmd: 'sudo apt update && sudo apt install -y docker.io docker-compose && sudo systemctl start docker',
        },
        {
          label: '3. Clone & Launch Container Stack',
          cmd: 'git clone <repo-url> && cd <repo-folder> && docker compose up -d --build',
        },
        {
          label: '4. Verify Security Group Inbound Ports',
          cmd: '# Allow Inbound Port 3000 (HTTP App) and 22 (SSH) in AWS EC2 Security Group',
        },
      ],
    },
  ];

  return (
    <div className="w-full max-w-4xl mx-auto space-y-6">
      {/* Intro Header */}
      <div className="glass-panel-elevated rounded-3xl p-6 sm:p-8 backdrop-blur-xl border border-purple-500/25">
        <div className="flex items-center gap-3 pb-5 border-b border-purple-900/40">
          <div className="w-10 h-10 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400 shrink-0">
            <Terminal className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
              DevOps &amp; Containerization Manual
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Complete reference for Docker Compose, AWS EC2, and MongoDB deployment.
            </p>
          </div>
        </div>

        {/* Quick Highlights */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mt-4 text-xs">
          <div className="p-3.5 bg-[#090d1a] rounded-2xl border border-purple-900/30 flex items-center gap-3">
            <Server className="w-4 h-4 text-purple-400 shrink-0" />
            <div>
              <span className="font-semibold text-white block">Node.js + Express</span>
              <span className="text-slate-400 text-[11px]">Multi-stage Alpine Runner</span>
            </div>
          </div>
          <div className="p-3.5 bg-[#090d1a] rounded-2xl border border-purple-900/30 flex items-center gap-3">
            <Database className="w-4 h-4 text-pink-400 shrink-0" />
            <div>
              <span className="font-semibold text-white block">MongoDB 6.0</span>
              <span className="text-slate-400 text-[11px]">Volume mount &amp; ping test</span>
            </div>
          </div>
          <div className="p-3.5 bg-[#090d1a] rounded-2xl border border-purple-900/30 flex items-center gap-3">
            <Cloud className="w-4 h-4 text-indigo-400 shrink-0" />
            <div>
              <span className="font-semibold text-white block">AWS EC2 Ready</span>
              <span className="text-slate-400 text-[11px]">Port 3000 exposed</span>
            </div>
          </div>
        </div>
      </div>

      {/* Sections List */}
      <div className="space-y-6">
        {sections.map((section, sIdx) => (
          <div
            key={sIdx}
            className="glass-panel rounded-3xl p-6 sm:p-8 border border-purple-500/20 space-y-4"
          >
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <FileCode className="w-4 h-4 text-purple-400" />
                <span>{section.title}</span>
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">{section.desc}</p>
            </div>

            <div className="space-y-3">
              {section.commands.map((c, cIdx) => {
                const uniqueId = sIdx * 100 + cIdx;
                return (
                  <div
                    key={cIdx}
                    className="p-3.5 bg-[#070a14] rounded-2xl border border-purple-900/40 font-mono text-xs"
                  >
                    <div className="flex items-center justify-between text-[11px] text-slate-400 font-sans mb-1.5">
                      <span className="font-medium text-slate-300">{c.label}</span>
                      <button
                        onClick={() => copyToClipboard(c.cmd, uniqueId)}
                        className="flex items-center gap-1 text-slate-400 hover:text-purple-300 transition-colors cursor-pointer"
                      >
                        {copiedIndex === uniqueId ? (
                          <>
                            <Check className="w-3.5 h-3.5 text-emerald-400" />
                            <span className="text-emerald-400 font-sans">Copied!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5" />
                            <span className="font-sans">Copy</span>
                          </>
                        )}
                      </button>
                    </div>
                    <pre className="text-purple-300 overflow-x-auto whitespace-pre-wrap select-all font-mono leading-relaxed">
                      {c.cmd}
                    </pre>
                  </div>
                );
              })}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
