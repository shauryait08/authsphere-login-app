import React, { useState } from 'react';
import { Mail, Lock, Eye, EyeOff, ArrowRight, Loader2, AlertCircle, CheckCircle2, Sparkles } from 'lucide-react';
import { loginApi } from '../services/api';
import { User, ValidationErrors } from '../types/auth';

interface LoginFormProps {
  onSuccess: (user: User) => void;
  onSwitchToRegister: () => void;
  onForgotPassword: () => void;
  onRefreshHealth: () => void;
}

export const LoginForm: React.FC<LoginFormProps> = ({
  onSuccess,
  onSwitchToRegister,
  onForgotPassword,
  onRefreshHealth,
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [loading, setLoading] = useState(false);
  const [googleLoading, setGoogleLoading] = useState(false);
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [serverAlert, setServerAlert] = useState<{
    type: 'error' | 'success';
    message: string;
  } | null>(null);

  const validate = (): boolean => {
    const newErrors: ValidationErrors = {};

    if (!email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      newErrors.email = 'Please enter a valid email address (e.g. alex@example.com).';
    }

    if (!password) {
      newErrors.password = 'Password is required.';
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters.';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setServerAlert(null);

    if (!validate()) return;

    setLoading(true);
    try {
      const response = await loginApi({
        email: email.trim().toLowerCase(),
        password,
      });

      if (response.success && response.user) {
        setServerAlert({
          type: 'success',
          message: response.message || 'Login successful! Welcome back.',
        });
        onRefreshHealth();
        setTimeout(() => {
          onSuccess(response.user!);
        }, 500);
      } else {
        setServerAlert({
          type: 'error',
          message: response.message || 'Invalid email or password. Please verify your credentials.',
        });
      }
    } catch (err: any) {
      setServerAlert({
        type: 'error',
        message: err.message || 'Unable to connect to the authentication server.',
      });
    } finally {
      setLoading(false);
    }
  };

  // Google OAuth UI button simulation
  const handleGoogleLogin = () => {
    setGoogleLoading(true);
    setTimeout(() => {
      setGoogleLoading(false);
      // Create authenticated mock Google session
      const googleUser: User = {
        name: 'Alex Mercer (Google)',
        email: email.trim() || 'alex.mercer.google@example.com',
        mobile: '+1 (555) 019-9922',
        createdAt: new Date(),
      };
      setServerAlert({
        type: 'success',
        message: 'Google authentication verified successfully!',
      });
      setTimeout(() => {
        onSuccess(googleUser);
      }, 500);
    }, 1000);
  };

  const handleFillDemo = () => {
    setEmail('alex.mercer@example.com');
    setPassword('securePass123!');
    setErrors({});
    setServerAlert(null);
  };

  return (
    <div className="w-full max-w-[420px] mx-auto">
      {/* Centered Glass Card styled exactly like reference image */}
      <div className="glass-panel-elevated rounded-[28px] p-7 sm:p-9 shadow-2xl relative overflow-hidden backdrop-blur-2xl transition-all border border-purple-500/25">
        {/* Ambient card top glow highlight */}
        <div className="absolute -top-24 left-1/2 -translate-x-1/2 w-56 h-32 bg-purple-600/30 blur-3xl pointer-events-none rounded-full" />
        
        {/* Header matching image_36609fe4.png */}
        <div className="mb-7 text-left relative z-10">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight font-display">
            Welcome back
          </h2>
          <p className="text-sm text-purple-200/70 mt-1.5 font-normal">
            Sign in to continue
          </p>
        </div>

        {/* Server Alert Message */}
        {serverAlert && (
          <div
            className={`mb-5 p-3.5 rounded-xl border flex items-start gap-2.5 text-xs sm:text-sm transition-all relative z-10 ${
              serverAlert.type === 'error'
                ? 'bg-rose-500/15 border-rose-500/30 text-rose-200'
                : 'bg-emerald-500/15 border-emerald-500/30 text-emerald-200'
            }`}
          >
            {serverAlert.type === 'error' ? (
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-400 mt-0.5" />
            ) : (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
            )}
            <span className="leading-snug">{serverAlert.message}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 relative z-10" noValidate>
          {/* Email field */}
          <div>
            <div className="relative">
              <input
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (errors.email) setErrors((prev) => ({ ...prev, email: undefined }));
                }}
                placeholder="Email address"
                className={`w-full px-4 py-3.5 glass-input rounded-2xl text-sm text-white placeholder-slate-400 focus:outline-none transition-all ${
                  errors.email ? 'border-rose-500/60' : ''
                }`}
              />
            </div>
            {errors.email && (
              <p className="text-[11px] text-rose-400 mt-1 pl-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                {errors.email}
              </p>
            )}
          </div>

          {/* Password field */}
          <div>
            <div className="relative">
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errors.password) setErrors((prev) => ({ ...prev, password: undefined }));
                }}
                placeholder="Password"
                className={`w-full pl-4 pr-11 py-3.5 glass-input rounded-2xl text-sm text-white placeholder-slate-400 focus:outline-none transition-all ${
                  errors.password ? 'border-rose-500/60' : ''
                }`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-purple-300 transition-colors cursor-pointer"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
            {errors.password && (
              <p className="text-[11px] text-rose-400 mt-1 pl-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                {errors.password}
              </p>
            )}
          </div>

          {/* Remember Me and Forgot Password */}
          <div className="flex items-center justify-between text-xs pt-1">
            <label className="flex items-center gap-2 cursor-pointer text-slate-300 hover:text-white select-none">
              <input
                type="checkbox"
                checked={rememberMe}
                onChange={(e) => setRememberMe(e.target.checked)}
                className="w-4 h-4 rounded border-purple-500/40 bg-[#0c1222] text-purple-600 focus:ring-purple-500/30 accent-purple-600 cursor-pointer"
              />
              <span>Remember me</span>
            </label>

            <button
              type="button"
              onClick={onForgotPassword}
              className="text-purple-400 hover:text-purple-300 font-medium transition-colors cursor-pointer"
            >
              Forgot Password?
            </button>
          </div>

          {/* Modern Login Button styled directly like image_36609fe4.png */}
          <button
            type="submit"
            disabled={loading}
            className="w-full mt-3 py-3.5 px-5 btn-primary-gradient text-white font-bold rounded-2xl text-base transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {loading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Signing in...</span>
              </>
            ) : (
              <>
                <span>Sign in</span>
                <span className="text-lg">→</span>
              </>
            )}
          </button>
        </form>

        {/* Divider */}
        <div className="relative my-6 text-center">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-purple-900/30" />
          </div>
          <span className="relative px-3 bg-[#11172a] text-[11px] text-slate-400 uppercase tracking-wider">
            Or continue with
          </span>
        </div>

        {/* Google Login UI Button */}
        <button
          type="button"
          onClick={handleGoogleLogin}
          disabled={googleLoading}
          className="w-full py-3 px-4 rounded-2xl bg-[#0b0f1e]/80 border border-purple-900/40 hover:border-purple-500/40 text-slate-200 hover:text-white text-xs sm:text-sm font-medium flex items-center justify-center gap-3 transition-all cursor-pointer shadow-sm disabled:opacity-60"
        >
          {googleLoading ? (
            <>
              <Loader2 className="w-4 h-4 animate-spin text-purple-400" />
              <span>Connecting Google Account...</span>
            </>
          ) : (
            <>
              <svg className="w-4 h-4" viewBox="0 0 24 24">
                <path
                  fill="#4285F4"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="#34A853"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
                />
                <path
                  fill="#EA4335"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
                />
              </svg>
              <span>Sign in with Google</span>
            </>
          )}
        </button>

        {/* Link to create new account matching image_36609fe4.png */}
        <div className="mt-6 text-center text-xs text-slate-400">
          <span>No account? </span>
          <button
            type="button"
            onClick={onSwitchToRegister}
            className="text-purple-400 hover:text-purple-300 font-semibold transition-colors cursor-pointer underline-offset-2 hover:underline"
          >
            Create one
          </button>
        </div>

        {/* Quick demo autofill helper */}
        <div className="mt-5 pt-4 border-t border-purple-900/30 flex items-center justify-between text-[11px] text-slate-400">
          <span>Testing environment?</span>
          <button
            type="button"
            onClick={handleFillDemo}
            className="text-purple-400 hover:text-purple-300 font-medium flex items-center gap-1 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3 h-3 text-pink-400" />
            <span>Fill Demo Credentials</span>
          </button>
        </div>
      </div>
    </div>
  );
};
