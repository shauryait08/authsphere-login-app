import React, { useState } from 'react';
import {
  User as UserIcon,
  Mail,
  Phone,
  Calendar,
  ShieldCheck,
  LogOut,
  Database,
  KeyRound,
  CheckCircle,
  Copy,
  Check,
  Server,
  Lock,
  ExternalLink,
} from 'lucide-react';
import { User } from '../types/auth';

interface UserProfileProps {
  user: User;
  onLogout: () => void;
  onRegisterAnother: () => void;
  onViewDatabase?: () => void;
  onOpenDocs?: () => void;
}

export const UserProfile: React.FC<UserProfileProps> = ({
  user,
  onLogout,
  onRegisterAnother,
  onViewDatabase,
  onOpenDocs,
}) => {
  const [copiedToken, setCopiedToken] = useState(false);

  // Generate simulated session JWT token for preview
  const mockJwt = `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.${btoa(
    JSON.stringify({
      id: user.id || user._id || 'user_' + Date.now(),
      email: user.email,
      name: user.name,
      iat: Math.floor(Date.now() / 1000),
      exp: Math.floor(Date.now() / 1000) + 86400,
    })
  ).replace(/=/g, '')}.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c`;

  const copyToken = () => {
    navigator.clipboard.writeText(mockJwt);
    setCopiedToken(true);
    setTimeout(() => setCopiedToken(false), 2000);
  };

  const formattedDate = user.createdAt
    ? new Date(user.createdAt).toLocaleString(undefined, {
        dateStyle: 'medium',
        timeStyle: 'short',
      })
    : 'Just now';

  const initials = user.name
    ? user.name
        .split(' ')
        .map((n) => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2)
    : 'AS';

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      {/* Top Banner Dashboard Card */}
      <div className="glass-panel-elevated rounded-3xl p-6 sm:p-8 relative overflow-hidden border border-purple-500/30">
        <div className="absolute top-0 right-0 w-80 h-80 bg-purple-600/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-5 pb-6 border-b border-purple-900/40">
          <div className="flex items-center gap-4">
            <div className="relative">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-pink-500 p-[2px] shadow-lg shadow-purple-600/30">
                <div className="w-full h-full bg-[#0b0f1e] rounded-[14px] flex items-center justify-center text-xl font-extrabold text-purple-200">
                  {initials}
                </div>
              </div>
              <span className="absolute -bottom-1 -right-1 w-4 h-4 rounded-full bg-emerald-400 border-2 border-[#0b0f1e] shadow-sm"></span>
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
                  {user.name}
                </h2>
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-500/15 border border-emerald-500/30 text-emerald-300 text-[11px] font-semibold">
                  <CheckCircle className="w-3 h-3" />
                  <span>Authenticated</span>
                </span>
              </div>
              <p className="text-xs sm:text-sm text-purple-300/80 mt-0.5 font-mono">{user.email}</p>
            </div>
          </div>

          <button
            onClick={onLogout}
            className="px-4 py-2 rounded-xl bg-purple-950/40 hover:bg-rose-950/60 border border-purple-800/40 hover:border-rose-700/50 text-slate-300 hover:text-rose-200 text-xs sm:text-sm font-medium transition-all flex items-center gap-2 cursor-pointer"
          >
            <LogOut className="w-4 h-4 text-rose-400" />
            <span>Sign Out</span>
          </button>
        </div>

        {/* User Profile Fields Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-6">
          <div className="p-4 rounded-2xl bg-[#090d1a]/80 border border-purple-900/30">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-purple-600/20 text-purple-400 flex items-center justify-center shrink-0">
                <UserIcon className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-400 block">Full Name</span>
                <span className="text-sm font-semibold text-white truncate block">{user.name}</span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-[#090d1a]/80 border border-purple-900/30">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center shrink-0">
                <Mail className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-400 block">Email Address</span>
                <span className="text-sm font-semibold text-white truncate block">{user.email}</span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-[#090d1a]/80 border border-purple-900/30">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-pink-600/20 text-pink-400 flex items-center justify-center shrink-0">
                <Phone className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-400 block">Mobile Phone</span>
                <span className="text-sm font-semibold text-white truncate block font-mono">
                  {user.mobile}
                </span>
              </div>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-[#090d1a]/80 border border-purple-900/30">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-purple-600/20 text-purple-300 flex items-center justify-center shrink-0">
                <Calendar className="w-4 h-4" />
              </div>
              <div className="min-w-0">
                <span className="text-[11px] text-slate-400 block">Registration Timestamp</span>
                <span className="text-sm font-semibold text-white truncate block tabular-nums">
                  {formattedDate}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Security Parameters Details */}
        <div className="mt-6 pt-5 border-t border-purple-900/40 grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-[#080c18] border border-purple-900/30">
            <Lock className="w-4 h-4 text-purple-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white block">Bcrypt Hashed</span>
              <span className="text-[11px] text-slate-400">10 Salt Rounds in MongoDB</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-[#080c18] border border-purple-900/30">
            <Database className="w-4 h-4 text-pink-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white block">Mongoose Schema</span>
              <span className="text-[11px] text-slate-400">Validated Collection: users</span>
            </div>
          </div>

          <div className="flex items-start gap-2.5 p-3 rounded-xl bg-[#080c18] border border-purple-900/30">
            <Server className="w-4 h-4 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold text-white block">Dockerized API</span>
              <span className="text-[11px] text-slate-400">Multi-stage Alpine Runner</span>
            </div>
          </div>
        </div>

        {/* Active JWT / Bearer Token preview */}
        <div className="mt-5 p-4 rounded-2xl bg-[#080b15] border border-purple-900/40">
          <div className="flex items-center justify-between mb-2">
            <div className="flex items-center gap-2">
              <KeyRound className="w-3.5 h-3.5 text-purple-400" />
              <span className="text-xs font-semibold text-slate-300">Active Bearer Token Preview</span>
            </div>
            <button
              onClick={copyToken}
              className="text-xs text-purple-300 hover:text-white flex items-center gap-1 transition-colors cursor-pointer"
            >
              {copiedToken ? (
                <>
                  <Check className="w-3 h-3 text-emerald-400" />
                  <span className="text-emerald-400">Copied!</span>
                </>
              ) : (
                <>
                  <Copy className="w-3 h-3" />
                  <span>Copy</span>
                </>
              )}
            </button>
          </div>
          <div className="p-2.5 rounded-lg bg-[#05070e] font-mono text-[11px] text-purple-300/80 break-all select-all">
            {mockJwt}
          </div>
        </div>

        {/* Bottom Actions */}
        <div className="mt-6 flex flex-wrap gap-3">
          {onViewDatabase && (
            <button
              onClick={onViewDatabase}
              className="px-4 py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-medium text-xs sm:text-sm transition-all flex items-center gap-2 cursor-pointer shadow-md shadow-purple-600/20"
            >
              <Database className="w-4 h-4" />
              <span>Inspect Database Users</span>
            </button>
          )}

          {onOpenDocs && (
            <button
              onClick={onOpenDocs}
              className="px-4 py-2.5 rounded-xl bg-[#0d1224] hover:bg-slate-800 border border-purple-900/40 text-slate-200 text-xs sm:text-sm font-medium transition-all flex items-center gap-2 cursor-pointer"
            >
              <ExternalLink className="w-4 h-4 text-purple-400" />
              <span>DevOps &amp; Docker Setup</span>
            </button>
          )}

          <button
            onClick={onRegisterAnother}
            className="px-4 py-2.5 rounded-xl bg-[#0d1224] hover:bg-slate-800 border border-purple-900/40 text-slate-200 text-xs sm:text-sm font-medium transition-all flex items-center gap-2 cursor-pointer"
          >
            <span>Register Another User</span>
          </button>
        </div>
      </div>
    </div>
  );
};
