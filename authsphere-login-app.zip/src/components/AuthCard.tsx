import React, { useState } from 'react';
import {
  User as UserIcon,
  Mail,
  Phone,
  Lock,
  Eye,
  EyeOff,
  ArrowRight,
  Loader2,
  AlertCircle,
  CheckCircle2,
  Sparkles,
} from 'lucide-react';
import { registerApi, loginApi } from '../services/api';
import { User, ValidationErrors } from '../types/auth';

interface AuthCardProps {
  onSuccess: (user: User, mode: 'login' | 'register') => void;
  onRefreshHealth: () => void;
}

export const AuthCard: React.FC<AuthCardProps> = ({
  onSuccess,
  onRefreshHealth,
}) => {
  const [mode, setMode] = useState<'login' | 'register'>('register');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);

  // Form inputs
  const [name, setName] = useState('');
  const [mobile, setMobile] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  // Validation & alerts
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [serverAlert, setServerAlert] = useState<{
    type: 'error' | 'success';
    message: string;
  } | null>(null);

  // Real-time client validator
  const validate = (): boolean => {
    const newErrors: ValidationErrors = {};

    // Email validation
    if (!email.trim()) {
      newErrors.email = 'Email address is required.';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) {
      newErrors.email = 'Please enter a valid email address (e.g. alex@example.com).';
    }

    // Password validation
    if (!password) {
      newErrors.password = 'Password is required.';
    } else if (password.length < 6) {
      newErrors.password = 'Password must be at least 6 characters long.';
    }

    // Register-only fields
    if (mode === 'register') {
      if (!name.trim()) {
        newErrors.name = 'Full name is required.';
      } else if (name.trim().length < 2) {
        newErrors.name = 'Name must be at least 2 characters.';
      }

      const cleanMobile = mobile.replace(/[\s\-\(\)\+]/g, '');
      if (!mobile.trim()) {
        newErrors.mobile = 'Mobile number is required.';
      } else if (!/^\d{10,15}$/.test(cleanMobile)) {
        newErrors.mobile = 'Please enter a valid 10-to-15 digit mobile number.';
      }

      if (confirmPassword && password !== confirmPassword) {
        newErrors.confirmPassword = 'Passwords do not match.';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setServerAlert(null);

    if (!validate()) {
      return;
    }

    setLoading(true);

    try {
      if (mode === 'register') {
        const response = await registerApi({
          name: name.trim(),
          mobile: mobile.trim(),
          email: email.trim().toLowerCase(),
          password,
        });

        if (response.success && response.user) {
          setServerAlert({
            type: 'success',
            message: response.message || 'Registration successful!',
          });
          onRefreshHealth();
          setTimeout(() => {
            onSuccess(response.user!, 'register');
          }, 600);
        } else {
          setServerAlert({
            type: 'error',
            message: response.message || 'Registration failed. Please try again.',
          });
        }
      } else {
        const response = await loginApi({
          email: email.trim().toLowerCase(),
          password,
        });

        if (response.success && response.user) {
          setServerAlert({
            type: 'success',
            message: response.message || 'Login successful!',
          });
          onRefreshHealth();
          setTimeout(() => {
            onSuccess(response.user!, 'login');
          }, 600);
        } else {
          setServerAlert({
            type: 'error',
            message: response.message || 'Invalid email or password.',
          });
        }
      }
    } catch (err: any) {
      setServerAlert({
        type: 'error',
        message: err.message || 'Server connection error.',
      });
    } finally {
      setLoading(false);
    }
  };

  const handleFillDemo = (type: 'new' | 'default') => {
    setServerAlert(null);
    setErrors({});
    if (type === 'new') {
      const randomSuffix = Math.floor(100 + Math.random() * 900);
      setName('Alex Mercer');
      setMobile(`+1 (555) 019-${randomSuffix}`);
      setEmail(`alex.mercer${randomSuffix}@example.com`);
      setPassword('securePass123!');
      setConfirmPassword('securePass123!');
    } else {
      setEmail('alex.mercer@example.com');
      setPassword('securePass123!');
    }
  };

  return (
    <div className="w-full max-w-md mx-auto">
      {/* Switcher Header */}
      <div className="flex rounded-xl bg-slate-900/90 p-1 border border-slate-800 mb-6">
        <button
          type="button"
          onClick={() => {
            setMode('register');
            setServerAlert(null);
            setErrors({});
          }}
          className={`flex-1 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all ${
            mode === 'register'
              ? 'bg-slate-800 text-white shadow-sm font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Create Account
        </button>
        <button
          type="button"
          onClick={() => {
            setMode('login');
            setServerAlert(null);
            setErrors({});
          }}
          className={`flex-1 py-2 text-xs sm:text-sm font-medium rounded-lg transition-all ${
            mode === 'login'
              ? 'bg-slate-800 text-white shadow-sm font-semibold'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Sign In
        </button>
      </div>

      {/* Main Card */}
      <div className="bg-slate-900/60 border border-slate-800 rounded-2xl p-6 sm:p-8 backdrop-blur-sm shadow-xl">
        <div className="mb-6">
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-display">
            {mode === 'register' ? 'Join AuthSphere' : 'Welcome Back'}
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            {mode === 'register'
              ? 'Enter your personal details to register with MongoDB.'
              : 'Sign in using your verified email and password.'}
          </p>
        </div>

        {/* Server Alert Message */}
        {serverAlert && (
          <div
            className={`mb-5 p-3.5 rounded-xl border flex items-start gap-2.5 text-xs sm:text-sm transition-all ${
              serverAlert.type === 'error'
                ? 'bg-red-500/10 border-red-500/30 text-red-300'
                : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
            }`}
          >
            {serverAlert.type === 'error' ? (
              <AlertCircle className="w-4 h-4 shrink-0 text-red-400 mt-0.5" />
            ) : (
              <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400 mt-0.5" />
            )}
            <span className="leading-snug">{serverAlert.message}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4" noValidate>
          {/* Field 1: Name (Register mode only) */}
          {mode === 'register' && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Full Name <span className="text-red-400">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <UserIcon className="w-4 h-4" />
                </div>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => {
                    setName(e.target.value);
                    if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                  }}
                  placeholder="e.g. Alex Mercer"
                  className={`w-full pl-10 pr-3 py-2.5 bg-slate-950/70 border rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 transition-all ${
                    errors.name
                      ? 'border-red-500/60 focus:ring-red-500/30'
                      : 'border-slate-800 focus:border-emerald-500/60 focus:ring-emerald-500/20'
                  }`}
                />
              </div>
              {errors.name && (
                <p className="text-[11px] text-red-400 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3 shrink-0" />
                  {errors.name}
                </p>
              )}
            </div>
          )}

          {/* Field 2: Mobile Number (Register mode only) */}
          {mode === 'register' && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Mobile Number <span className="text-red-400">*</span>
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <Phone className="w-4 h-4" />
                </div>
                <input
                  type="tel"
                  value={mobile}
                  onChange={(e) => {
                    setMobile(e.target.value);
                    if (errors.mobile) setErrors((prev) => ({ ...prev, mobile: undefined }));
                  }}
                  placeholder="e.g. +1 555-019-2834 or 9876543210"
                  className={`w-full pl-10 pr-3 py-2.5 bg-slate-950/70 border rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 transition-all ${
                    errors.mobile
                      ? 'border-red-500/60 focus:ring-red-500/30'
                      : 'border-slate-800 focus:border-emerald-500/60 focus:ring-emerald-500/20'
                  }`}
                />
              </div>
              {errors.mobile && (
                <p className="text-[11px] text-red-400 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3 shrink-0" />
                  {errors.mobile}
                </p>
              )}
            </div>
          )}

          {/* Field 3: Email (Both modes) */}
          <div>
            <label className="block text-xs font-medium text-slate-300 mb-1.5">
              Email Address <span className="text-red-400">*</span>
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                <Mail className="w-4 h-4" />
              </div>
              <input
                type="email"
                value={email}
                onChange={(e) => {
                  setEmail(e.target.value);
                  if (errors.email) setErrors((prev) => ({ ...prev, email: undefined }));
                }}
                placeholder="e.g. alex@example.com"
                className={`w-full pl-10 pr-3 py-2.5 bg-slate-950/70 border rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 transition-all ${
                  errors.email
                    ? 'border-red-500/60 focus:ring-red-500/30'
                    : 'border-slate-800 focus:border-emerald-500/60 focus:ring-emerald-500/20'
                }`}
              />
            </div>
            {errors.email && (
              <p className="text-[11px] text-red-400 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                {errors.email}
              </p>
            )}
          </div>

          {/* Field 4: Password (Both modes) */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="block text-xs font-medium text-slate-300">
                Password <span className="text-red-400">*</span>
              </label>
              {mode === 'login' && (
                <span className="text-[11px] text-slate-500">
                  Must be at least 6 characters
                </span>
              )}
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                <Lock className="w-4 h-4" />
              </div>
              <input
                type={showPassword ? 'text' : 'password'}
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                  if (errors.password) setErrors((prev) => ({ ...prev, password: undefined }));
                }}
                placeholder="••••••••"
                className={`w-full pl-10 pr-10 py-2.5 bg-slate-950/70 border rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 transition-all ${
                  errors.password
                    ? 'border-red-500/60 focus:ring-red-500/30'
                    : 'border-slate-800 focus:border-emerald-500/60 focus:ring-emerald-500/20'
                }`}
              />
              <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-500 hover:text-slate-300 transition-colors"
                aria-label={showPassword ? 'Hide password' : 'Show password'}
              >
                {showPassword ? (
                  <EyeOff className="w-4 h-4" />
                ) : (
                  <Eye className="w-4 h-4" />
                )}
              </button>
            </div>
            {errors.password && (
              <p className="text-[11px] text-red-400 mt-1 flex items-center gap-1">
                <AlertCircle className="w-3 h-3 shrink-0" />
                {errors.password}
              </p>
            )}
          </div>

          {/* Confirm Password (Register mode only) */}
          {mode === 'register' && (
            <div>
              <label className="block text-xs font-medium text-slate-300 mb-1.5">
                Confirm Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-500">
                  <Lock className="w-4 h-4" />
                </div>
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={confirmPassword}
                  onChange={(e) => {
                    setConfirmPassword(e.target.value);
                    if (errors.confirmPassword) setErrors((prev) => ({ ...prev, confirmPassword: undefined }));
                  }}
                  placeholder="••••••••"
                  className={`w-full pl-10 pr-3 py-2.5 bg-slate-950/70 border rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-2 transition-all ${
                    errors.confirmPassword
                      ? 'border-red-500/60 focus:ring-red-500/30'
                      : 'border-slate-800 focus:border-emerald-500/60 focus:ring-emerald-500/20'
                  }`}
                />
              </div>
              {errors.confirmPassword && (
                <p className="text-[11px] text-red-400 mt-1 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3 shrink-0" />
                  {errors.confirmPassword}
                </p>
              )}
            </div>
          )}

          {/* Submit Button */}
          <button
            type="submit"
            disabled={loading}
            className="w-full mt-2 py-3 px-4 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-semibold rounded-xl text-sm transition-all duration-150 flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/10 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Processing...</span>
              </>
            ) : mode === 'register' ? (
              <>
                <span>Create MongoDB Account</span>
                <ArrowRight className="w-4 h-4" />
              </>
            ) : (
              <>
                <span>Sign In to Account</span>
                <ArrowRight className="w-4 h-4" />
              </>
            )}
          </button>
        </form>

        {/* Quick Demo Autofill Helper */}
        <div className="mt-6 pt-5 border-t border-slate-800 flex items-center justify-between text-xs text-slate-400">
          <span>Need test credentials?</span>
          <button
            type="button"
            onClick={() => handleFillDemo(mode === 'register' ? 'new' : 'default')}
            className="text-emerald-400 hover:text-emerald-300 font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Fill Demo Data</span>
          </button>
        </div>
      </div>
    </div>
  );
};
