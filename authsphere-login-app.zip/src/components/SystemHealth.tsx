import React, { useState } from 'react';
import {
  Activity,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Server,
  Database,
  Clock,
  Code2,
} from 'lucide-react';
import { HealthResponse } from '../types/auth';

interface SystemHealthProps {
  health: HealthResponse | null;
  loading: boolean;
  onRefresh: () => void;
}

export const SystemHealth: React.FC<SystemHealthProps> = ({
  health,
  loading,
  onRefresh,
}) => {
  const [showJson, setShowJson] = useState(false);

  const formatUptime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}m ${secs}s`;
  };

  return (
    <div className="w-full max-w-2xl mx-auto space-y-6">
      {/* Header card */}
      <div className="glass-panel-elevated rounded-3xl p-6 sm:p-8 backdrop-blur-xl border border-purple-500/25">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-purple-900/40">
          <div>
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-xl bg-purple-600/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
                <Activity className="w-5 h-5" />
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white font-display">
                API Health &amp; Runtime Engine
              </h2>
            </div>
            <p className="text-xs sm:text-sm text-slate-400 mt-1">
              Verifies the REST API health-check endpoint: <code className="text-purple-300 font-mono">GET /health</code>
            </p>
          </div>
          <button
            onClick={onRefresh}
            disabled={loading}
            className="self-start sm:self-auto px-4 py-2 bg-purple-600/20 hover:bg-purple-600/40 border border-purple-500/30 text-purple-200 text-xs font-medium rounded-xl transition-all flex items-center gap-2 cursor-pointer disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 text-purple-400 ${loading ? 'animate-spin' : ''}`} />
            <span>Ping /health</span>
          </button>
        </div>

        {/* Metric Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6">
          {/* Status */}
          <div className="p-4 bg-[#090d1a] border border-purple-900/30 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium">Service Status</span>
              <Server className="w-4 h-4 text-purple-400" />
            </div>
            <div className="flex items-center gap-2">
              {health?.status === 'ok' ? (
                <>
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                  <span className="text-sm font-semibold text-white uppercase tracking-wider">
                    HEALTHY
                  </span>
                </>
              ) : (
                <>
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                  <span className="text-sm font-semibold text-amber-300">
                    CONNECTING
                  </span>
                </>
              )}
            </div>
          </div>

          {/* Database Connection */}
          <div className="p-4 bg-[#090d1a] border border-purple-900/30 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium">Database Backend</span>
              <Database className="w-4 h-4 text-pink-400" />
            </div>
            <div className="flex items-center gap-2">
              <span
                className={`w-2 h-2 rounded-full ${
                  health?.database.connected ? 'bg-emerald-400 animate-pulse' : 'bg-purple-400'
                }`}
              />
              <span className="text-xs font-semibold text-white">
                {health?.database.connected ? 'MongoDB Ready' : 'In-Memory Fallback'}
              </span>
            </div>
            <span className="text-[10px] text-slate-400 block mt-1">
              {health?.database.type}
            </span>
          </div>

          {/* Server Uptime */}
          <div className="p-4 bg-[#090d1a] border border-purple-900/30 rounded-2xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium">Server Uptime</span>
              <Clock className="w-4 h-4 text-indigo-400" />
            </div>
            <div className="text-sm font-semibold text-white font-mono tabular-nums">
              {health?.uptime !== undefined ? formatUptime(health.uptime) : '0m 0s'}
            </div>
            <span className="text-[10px] text-slate-400 block mt-1">
              Node.js + Express
            </span>
          </div>
        </div>

        {/* Toggle Raw JSON Response */}
        <div className="mt-6 pt-5 border-t border-purple-900/40">
          <button
            onClick={() => setShowJson(!showJson)}
            className="text-xs text-purple-300 hover:text-purple-200 font-medium flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Code2 className="w-3.5 h-3.5 text-purple-400" />
            <span>{showJson ? 'Hide Raw API JSON' : 'Inspect Raw GET /health JSON Response'}</span>
          </button>

          {showJson && (
            <div className="mt-3 p-4 bg-[#060810] border border-purple-900/50 rounded-2xl font-mono text-xs text-purple-300 overflow-x-auto">
              <pre>{JSON.stringify(health, null, 2)}</pre>
            </div>
          )}
        </div>
      </div>

      {/* Endpoint Spec Card */}
      <div className="glass-panel rounded-3xl p-6 sm:p-8 border border-purple-500/20">
        <h3 className="text-sm font-semibold text-white mb-3">
          Configured Authentication &amp; Health Endpoints
        </h3>
        <div className="space-y-2 text-xs">
          <div className="flex items-center justify-between p-3 bg-[#0a0e1c] rounded-xl border border-purple-900/30">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                GET
              </span>
              <span className="font-mono text-purple-200">/health</span>
            </div>
            <span className="text-slate-400 text-[11px]">System uptime &amp; DB status</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-[#0a0e1c] rounded-xl border border-purple-900/30">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                POST
              </span>
              <span className="font-mono text-purple-200">/api/auth/register</span>
            </div>
            <span className="text-slate-400 text-[11px]">Validates, hashes password &amp; stores in Mongo</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-[#0a0e1c] rounded-xl border border-purple-900/30">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                POST
              </span>
              <span className="font-mono text-purple-200">/api/auth/login</span>
            </div>
            <span className="text-slate-400 text-[11px]">Verifies credentials with bcrypt compare</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-[#0a0e1c] rounded-xl border border-purple-900/30">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-purple-500/15 text-purple-300 border border-purple-500/30">
                POST
              </span>
              <span className="font-mono text-purple-200">/api/auth/forgot-password</span>
            </div>
            <span className="text-slate-400 text-[11px]">Generates 6-digit recovery code</span>
          </div>

          <div className="flex items-center justify-between p-3 bg-[#0a0e1c] rounded-xl border border-purple-900/30">
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                GET
              </span>
              <span className="font-mono text-purple-200">/api/auth/users</span>
            </div>
            <span className="text-slate-400 text-[11px]">Returns sanitized users list for inspection</span>
          </div>
        </div>
      </div>
    </div>
  );
};
