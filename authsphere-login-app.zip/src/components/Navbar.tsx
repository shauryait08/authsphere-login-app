import React from 'react';
import { Database, Activity, Terminal, Shield, Sparkles } from 'lucide-react';

interface NavbarProps {
  activeTab: 'auth' | 'health' | 'database' | 'docs';
  setActiveTab: (tab: 'auth' | 'health' | 'database' | 'docs') => void;
  isDbConnected: boolean | null;
  onOpenDockerGuide?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  activeTab,
  setActiveTab,
  isDbConnected,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full border-b border-purple-900/30 bg-[#0b0f1d]/80 backdrop-blur-xl transition-all">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
        {/* Zone 1: Branding and Logo */}
        <div 
          onClick={() => setActiveTab('auth')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="relative">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-purple-600 via-indigo-600 to-pink-500 p-[1.5px] shadow-lg shadow-purple-600/30 transition-transform duration-300 group-hover:scale-105">
              <div className="w-full h-full bg-[#0d1224] rounded-[10px] flex items-center justify-center text-purple-300">
                <Shield className="w-4 h-4 text-purple-400 group-hover:text-pink-400 transition-colors" />
              </div>
            </div>
            <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-400 border-2 border-[#0b0f1d]"></span>
          </div>

          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-lg font-black tracking-tight text-white font-display">
                Auth<span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">Sphere</span>
              </span>
              <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-purple-500/15 border border-purple-500/30 text-purple-300 tracking-wider">
                v1.0
              </span>
            </div>
            <p className="text-[10px] text-slate-400 hidden sm:block">MongoDB &amp; Express Identity Engine</p>
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm font-medium">
          <button
            onClick={() => setActiveTab('auth')}
            className={`px-3 py-1.5 rounded-lg transition-all duration-200 cursor-pointer ${
              activeTab === 'auth'
                ? 'bg-purple-600/20 text-purple-200 border border-purple-500/40 shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            Auth Portal
          </button>
          
          <button
            onClick={() => setActiveTab('database')}
            className={`px-3 py-1.5 rounded-lg transition-all duration-200 flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'database'
                ? 'bg-purple-600/20 text-purple-200 border border-purple-500/40 shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Database className="w-3.5 h-3.5 text-purple-400" />
            <span className="hidden sm:inline">Database Users</span>
            <span className="sm:hidden">Users</span>
          </button>

          <button
            onClick={() => setActiveTab('health')}
            className={`px-3 py-1.5 rounded-lg transition-all duration-200 flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'health'
                ? 'bg-purple-600/20 text-purple-200 border border-purple-500/40 shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Activity className="w-3.5 h-3.5 text-indigo-400" />
            <span className="hidden sm:inline">Health API</span>
            <span className="sm:hidden">Health</span>
          </button>

          <button
            onClick={() => setActiveTab('docs')}
            className={`px-3 py-1.5 rounded-lg transition-all duration-200 flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'docs'
                ? 'bg-purple-600/20 text-purple-200 border border-purple-500/40 shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/50'
            }`}
          >
            <Terminal className="w-3.5 h-3.5 text-pink-400" />
            <span className="hidden sm:inline">DevOps Guide</span>
            <span className="sm:hidden">DevOps</span>
          </button>
        </nav>

        {/* Zone 3: Live Database & Engine indicator */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full border border-purple-500/20 bg-[#101426] text-xs">
            <span
              className={`w-2 h-2 rounded-full ${
                isDbConnected === true
                  ? 'bg-emerald-400 shadow-[0_0_8px_rgba(52,211,153,0.8)] animate-pulse'
                  : isDbConnected === false
                  ? 'bg-purple-400 shadow-[0_0_8px_rgba(168,85,247,0.8)]'
                  : 'bg-slate-500'
              }`}
            />
            <span className="text-slate-300 font-mono text-[11px] hidden md:inline">
              {isDbConnected === true
                ? 'MongoDB: Connected'
                : isDbConnected === false
                ? 'Storage: Safe Fallback'
                : 'Connecting API...'}
            </span>
            <span className="text-slate-300 font-mono text-[11px] md:hidden">
              {isDbConnected ? 'Mongo DB' : 'Active'}
            </span>
          </div>
        </div>
      </div>
    </header>
  );
};
