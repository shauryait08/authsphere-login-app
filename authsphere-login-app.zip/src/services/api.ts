import { AuthResponse, HealthResponse, User } from '../types/auth';

const API_BASE = '/api/auth';

export async function registerApi(data: {
  name: string;
  mobile: string;
  email: string;
  password: string;
}): Promise<AuthResponse> {
  try {
    const res = await fetch(`${API_BASE}/register`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    const result = await res.json();
    return result;
  } catch (err: any) {
    return {
      success: false,
      message: err.message || 'Network error occurred while connecting to the authentication server.',
    };
  }
}

export async function loginApi(data: {
  email: string;
  password: string;
}): Promise<AuthResponse> {
  try {
    const res = await fetch(`${API_BASE}/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    const result = await res.json();
    return result;
  } catch (err: any) {
    return {
      success: false,
      message: err.message || 'Network error occurred while connecting to the authentication server.',
    };
  }
}

export async function fetchHealthApi(): Promise<HealthResponse | null> {
  try {
    const res = await fetch('/health');
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } catch (err) {
    try {
      const fallbackRes = await fetch('/api/health');
      if (fallbackRes.ok) return await fallbackRes.json();
    } catch {}
    return null;
  }
}

export async function fetchUsersApi(): Promise<{ success: boolean; count?: number; database?: string; users?: User[]; message?: string }> {
  try {
    const res = await fetch(`${API_BASE}/users`);
    return await res.json();
  } catch (err: any) {
    return {
      success: false,
      message: err.message || 'Unable to fetch users list.',
    };
  }
}

export async function forgotPasswordApi(email: string): Promise<AuthResponse> {
  try {
    const res = await fetch(`${API_BASE}/forgot-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email }),
    });
    return await res.json();
  } catch (err: any) {
    return {
      success: false,
      message: err.message || 'Error sending password reset request.',
    };
  }
}

export async function resetPasswordApi(data: {
  email: string;
  code: string;
  newPassword: string;
}): Promise<AuthResponse> {
  try {
    const res = await fetch(`${API_BASE}/reset-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });
    return await res.json();
  } catch (err: any) {
    return {
      success: false,
      message: err.message || 'Error resetting password.',
    };
  }
}

