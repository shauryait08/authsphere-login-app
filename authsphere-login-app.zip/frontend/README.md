# Frontend Application

The frontend is a modern, responsive React + Vite application styled with Tailwind CSS.

## Features
- **Registration Form**: Validates Full Name, Mobile Number, Email Address, and Password with instant visual feedback.
- **Login Form**: Authenticates user against backend API and verifies passwords hashed with bcrypt.
- **Real-time API Health Monitor**: Pings `GET /health` to display server uptime and MongoDB database state.
- **MongoDB User Explorer**: Live view of registered documents stored in MongoDB with secure bcrypt hashed strings.
- **DevOps Guide**: Interactive terminal cheatsheet with copy-paste commands for Docker, Docker Compose, cURL, and AWS EC2.

## Structure
- `src/components/AuthCard.tsx`: Responsive Register & Login forms with field-level validation.
- `src/components/UserProfile.tsx`: Authenticated user profile displaying stored document details.
- `src/components/SystemHealth.tsx`: Live dashboard for `/health` endpoint and MongoDB status.
- `src/components/DatabaseViewer.tsx`: MongoDB registered users inspector.
- `src/components/DevOpsDocsModal.tsx`: Complete command manual for DevOps and EC2.
- `src/services/api.ts`: Typed REST API client.

## Running Locally
From project root:
```bash
npm run dev
```
Runs the full-stack server on `http://localhost:3000`.
