# AuthSphere — Full-Stack Login/Register Web Application connected to MongoDB

A clean, modern, and beginner-friendly full-stack web application featuring a responsive **Login & Registration Form** backed by a **Node.js + Express REST API** and **MongoDB** with **Mongoose**.

---

## 🚀 Key Highlights & Features

### Frontend (React + Vite + Tailwind CSS)
* **Modern Clean UI**: Designed with high-contrast slate surfaces, responsive across desktop, tablet, and mobile devices.
* **Fields**:
  * **Name** (minimum 2 characters, trimmed)
  * **Mobile Number** (validated 10–15 digits)
  * **Email** (standard email format validation)
  * **Password** (minimum 6 characters with show/hide toggle)
* **Interactive Validation**: Real-time validation messages display helpful guidance per field.
* **Autofill Demo Button**: Fast 1-click test data population for instant evaluation.
* **Post-Auth Profile View**: Shows authenticated user details, account creation timestamp, and active session with a Sign Out option.
* **Built-in System Health & DB Inspector**: Live ping to `GET /health` and real-time MongoDB user document browser.

### Backend (Node.js + Express.js + Mongoose)
* **REST APIs**:
  * `POST /api/auth/register` — Registers user, validates inputs, hashes password, saves to MongoDB.
  * `POST /api/auth/login` — Authenticates email & verifies password hash.
  * `GET /health` — Health check endpoint returning uptime and database connection status.
  * `GET /api/auth/users` — Returns sanitized registered users (passwords never exposed).
* **Mongoose User Model & Schema**:
  ```javascript
  {
    name: String,      // required, trimmed
    mobile: String,    // required, 10-15 digits
    email: String,     // required, unique, validated
    password: String,  // required, hashed with bcrypt
    createdAt: Date    // default: Date.now
  }
  ```
* **Security**:
  * Passwords hashed using `bcrypt` with salt rounds. Plain-text passwords are never saved or exposed.
  * Input validation on both client and server sides for email and mobile numbers.
  * Safe error responses (never leaks database internals or stack traces).
* **Environment-driven**: All connection strings loaded from `.env` via `process.env.MONGODB_URI`.

---

## 📂 Project Structure

```text
.
├── backend/
│   ├── config/
│   │   ├── db.js             # Mongoose connection with safe fallback
│   │   └── db.ts
│   ├── controllers/
│   │   ├── authController.js # Register, Login, Health, Users logic
│   │   └── authController.ts
│   ├── models/
│   │   ├── User.js           # Mongoose User schema & bcrypt pre-save hook
│   │   └── User.ts
│   ├── routes/
│   │   ├── authRoutes.js     # REST API route declarations
│   │   └── authRoutes.ts
│   ├── server.js             # Standalone Express server (Port 5000)
│   └── .env.example          # Backend sample environment variables
├── frontend/
│   ├── package.json          # Frontend package config
│   └── README.md             # Frontend architectural overview
├── src/
│   ├── components/
│   │   ├── AuthCard.tsx      # Register & Login form with validation
│   │   ├── DatabaseViewer.tsx# MongoDB stored documents explorer
│   │   ├── DevOpsDocsModal.tsx# DevOps commands cheatsheet
│   │   ├── Navbar.tsx        # Top Bar Contract navigation
│   │   ├── SystemHealth.tsx  # GET /health monitor
│   │   └── UserProfile.tsx   # Authenticated session card
│   ├── services/
│   │   └── api.ts            # Client API client
│   ├── types/
│   │   └── auth.ts           # TypeScript interfaces
│   ├── App.tsx               # Main application container
│   ├── index.css             # Tailwind CSS & global styling
│   └── main.tsx              # React DOM mounting
├── .dockerignore             # Docker build ignores
├── .env.example              # Full-stack root environment template
├── .gitignore                # Git exclusions
├── docker-compose.yml        # Docker Compose configuration (App + MongoDB 6.0)
├── Dockerfile                # Multi-stage production container build
├── index.html                # HTML entry point with metadata
├── package.json              # Project scripts & dependencies
├── README.md                 # Complete documentation & commands
├── server.ts                 # Full-stack dev & prod server (Port 3000)
├── tsconfig.json             # TypeScript compiler settings
└── vite.config.ts            # Vite configuration
```

---

## 🛠️ DevOps & Execution Commands

### 1. Install Dependencies
```bash
npm install
```

### 2. Run Locally

#### Option A: Full-Stack (Frontend UI + API on Port 3000)
```bash
npm run dev
```
Open [http://localhost:3000](http://localhost:3000) in your browser.

#### Option B: Standalone Node.js Backend Server (Port 5000)
```bash
npm run start:backend
# or: node backend/server.js
```

### 3. Build Docker Image
```bash
docker build -t authsphere-app .
```

### 4. Run with Docker Compose (Application + MongoDB 6.0)
```bash
docker compose up --build -d
```
This starts:
- **authsphere_app** on port `3000`
- **authsphere_mongo** on port `27017` with data persistence on volume `mongo_data`

### 5. View Logs
```bash
# View combined logs
docker compose logs -f

# View application logs only
docker compose logs -f app

# View MongoDB logs only
docker compose logs -f mongo
```

### 6. Stop Containers
```bash
docker compose stop
```

### 7. Remove Containers & Networks
```bash
# Stop and remove containers and network
docker compose down

# Stop and remove containers, networks AND database volume data
docker compose down -v
```

---

## 📡 API Reference & cURL Testing

### 1. Health-Check Endpoint
* **Method**: `GET /health`
* **Response**:
```json
{
  "status": "ok",
  "message": "Authentication REST API is running healthy",
  "timestamp": "2026-10-03T10:00:00.000Z",
  "uptime": 120,
  "database": {
    "connected": true,
    "type": "MongoDB (Mongoose)",
    "uri": "[Configured in .env]"
  }
}
```
* **cURL Command**:
```bash
curl -X GET http://localhost:3000/health
```

### 2. User Registration
* **Method**: `POST /api/auth/register`
* **Headers**: `Content-Type: application/json`
* **Body**:
```json
{
  "name": "Jane Cooper",
  "mobile": "9876543210",
  "email": "jane.cooper@example.com",
  "password": "Password123!"
}
```
* **Success Response (201 Created)**:
```json
{
  "success": true,
  "message": "User registered successfully!",
  "database": "MongoDB",
  "user": {
    "id": "670c5a31b...",
    "name": "Jane Cooper",
    "mobile": "9876543210",
    "email": "jane.cooper@example.com",
    "createdAt": "2026-10-03T10:02:15.123Z"
  }
}
```
* **cURL Command**:
```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Jane Cooper",
    "mobile": "9876543210",
    "email": "jane.cooper@example.com",
    "password": "Password123!"
  }'
```

### 3. User Login
* **Method**: `POST /api/auth/login`
* **Headers**: `Content-Type: application/json`
* **Body**:
```json
{
  "email": "jane.cooper@example.com",
  "password": "Password123!"
}
```
* **Success Response (200 OK)**:
```json
{
  "success": true,
  "message": "Login successful! Welcome back.",
  "user": {
    "id": "670c5a31b...",
    "name": "Jane Cooper",
    "mobile": "9876543210",
    "email": "jane.cooper@example.com",
    "createdAt": "2026-10-03T10:02:15.123Z"
  }
}
```
* **cURL Command**:
```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "jane.cooper@example.com",
    "password": "Password123!"
  }'
```

---

## ☁️ Deployment on AWS EC2 (Ubuntu)

Follow these simple steps to deploy the application on an AWS EC2 instance:

### Step 1: Launch an Ubuntu EC2 Instance
1. In the AWS Management Console, launch an **Ubuntu 22.04 LTS** or **24.04 LTS** instance (`t3.small` or `t3.micro`).
2. Configure **Security Group** Inbound rules:
   * **Port 22** (SSH) from your IP
   * **Port 3000** (Custom TCP) from `0.0.0.0/0` (or Port 80 if using reverse proxy)
   * *(Optional)* **Port 27017** should remain private (do NOT open to 0.0.0.0/0)

### Step 2: SSH into EC2 & Install Docker
```bash
ssh -i "your-key.pem" ubuntu@<your-ec2-public-ip>

# Update package lists & install Docker and Docker Compose
sudo apt update
sudo apt install -y docker.io docker-compose
sudo systemctl enable --now docker
sudo usermod -aG docker ubuntu
newgrp docker
```

### Step 3: Clone Code & Configure Environment
```bash
git clone <your-repository-url>
cd <repository-folder>

# Copy environment variables
cp .env.example .env
```

### Step 4: Run Application Stack
```bash
docker compose up --build -d
```

### Step 5: Verify Deployment
Visit in your browser:
```text
http://<your-ec2-public-ip>:3000
```
Or test the health-check:
```bash
curl http://<your-ec2-public-ip>:3000/health
```

---

## 🛡️ Security Design Notes

1. **Password Encryption**: All passwords undergo `bcrypt` salting (10 rounds) prior to storage in MongoDB.
2. **Plain-Text Exclusion**: The Mongoose user model never stores raw passwords, and API responses exclude the password field.
3. **No Hardcoded Credentials**: MongoDB URI and configuration are read exclusively from environment variables (`.env`).
4. **Validation Guardrails**:
   * Name: minimum 2 characters.
   * Mobile: 10–15 digits format check.
   * Email: standard regex validation.
   * Password: minimum 6 characters.

---

## 📄 License
MIT License. Built for clean and secure full-stack authentication with MongoDB.
